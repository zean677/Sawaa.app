# SAWA — سوا
## Super Community Economy App

[![CI](https://github.com/zein-apps/sawa/actions/workflows/ci.yml/badge.svg)](https://github.com/zein-apps/sawa/actions)

---

## Overview

SAWA is a production-grade fintech super app for Syria and the Arab world.

**Stack:** React Native (Expo SDK 51) + NestJS + PostgreSQL + Redis + BullMQ

**Developer:** Zein Apps | `com.sawa.app`

---

## Quick Start

### Prerequisites
- Node.js 20+
- pnpm 9+
- Docker + Docker Compose

### 1. Clone & Setup

```bash
git clone https://github.com/zein-apps/sawa.git
cd sawa
cp .env.example .env
# Edit .env with your values
```

### 2. Start Infrastructure

```bash
docker compose up -d
# Waits for: PostgreSQL, Redis, Meilisearch, MailHog
```

### 3. Generate RSA Keys for JWT

```bash
node -e "
const {generateKeyPairSync} = require('crypto');
const {privateKey, publicKey} = generateKeyPairSync('rsa', {modulusLength: 4096});
console.log('JWT_PRIVATE_KEY=' + JSON.stringify(privateKey.export({type:'pkcs8',format:'pem'})));
console.log('JWT_PUBLIC_KEY=' + JSON.stringify(publicKey.export({type:'spki',format:'pem'})));
"
# Copy output to .env
```

### 4. Install Dependencies

```bash
pnpm install
```

### 5. Database Setup

```bash
# Generate migrations from schema
pnpm db:generate

# Run migrations
pnpm db:migrate

# Seed initial data (app_config, payment_methods, missions, etc.)
pnpm db:seed
```

### 6. Run Development

```bash
# Start API (port 3000)
pnpm --filter @sawa/api dev

# Start Mobile (in a new terminal)
pnpm --filter @sawa/mobile dev

# Or run both with Turborepo
pnpm dev
```

### 7. Verify Setup

```bash
# API health check
curl http://localhost:3000/api/v1/health

# API docs (development only)
open http://localhost:3000/docs

# MailHog (email preview)
open http://localhost:8025

# Meilisearch dashboard
open http://localhost:7700
```

---

## Project Structure

```
sawa/
├── apps/
│   ├── api/                    # NestJS + Fastify backend
│   │   └── src/
│   │       ├── modules/        # Feature modules
│   │       │   ├── auth/       # OTP, JWT, Google OAuth
│   │       │   ├── ledger/     # Double-entry bookkeeping
│   │       │   ├── wallet/     # Balances, transfers
│   │       │   ├── escrow/     # Escrow engine
│   │       │   ├── market/     # Marketplace
│   │       │   ├── agents/     # Human ATM agents
│   │       │   ├── chat/       # Realtime chat
│   │       │   ├── trust/      # Trust score engine
│   │       │   ├── notifications/ # FCM push
│   │       │   ├── premium/    # Subscriptions
│   │       │   ├── ai/         # AI assistant
│   │       │   ├── admin/      # Admin dashboard
│   │       │   ├── queues/     # BullMQ (14 queues)
│   │       │   └── health/     # Health checks
│   │       ├── database/       # Drizzle schema + migrations
│   │       └── common/         # Guards, filters, interceptors
│   └── mobile/                 # React Native Expo
│       ├── app/                # Expo Router screens
│       ├── components/         # Reusable components
│       ├── stores/             # Zustand stores
│       ├── services/           # API service layer
│       ├── constants/          # App constants, colors
│       └── i18n/               # Arabic + English translations
└── packages/
    └── shared/                 # Shared types + validators
```

---

## Financial Safety

All monetary operations follow these rules (enforced at multiple layers):

1. **Double-entry bookkeeping** — every SP in = SP out
2. **Idempotency keys** — prevents double-spend on retry
3. **Row-level locking** — `SELECT FOR UPDATE` before balance changes
4. **DB constraints** — `available_balance >= 0` at database level
5. **Immutable ledger** — trigger prevents UPDATE/DELETE on entries
6. **Daily reconciliation** — 2AM job verifies all ledgers match
7. **Balance snapshots** — 3AM daily snapshots for audit/recovery

---

## Environment Variables

See `.env.example` for complete documentation. Required for minimum startup:

```env
DATABASE_URL=postgresql://sawa:sawa_dev_password_2024@localhost:5432/sawa_dev
REDIS_URL=redis://:sawa_redis_2024@localhost:6379
JWT_PRIVATE_KEY=...  # RS256 4096-bit
JWT_PUBLIC_KEY=...   # RS256 4096-bit
OTP_SECRET=...       # 64-char hex
```

---

## BullMQ Queues (14 total)

| Queue | Purpose | Schedule |
|---|---|---|
| notifications | FCM delivery | On-demand |
| image-processing | Compress + watermark | On-demand |
| ai-moderation | Content scanning | On-demand |
| fraud-detection | Rules engine | On-demand |
| escrow-auto-release | Release expired | Every 30 min |
| post-expiry | Expire market posts | Every 1 hour |
| reconciliation | Verify ledger | Daily 2AM |
| balance-snapshot | Daily snapshots | Daily 3AM |
| trust-score-update | Score changes | On-demand |
| email | OTP + alerts | On-demand |
| whatsapp | Meta Cloud API | On-demand |
| premium-renewal | Auto-renew | Daily 9AM |
| data-cleanup | GDPR + expired | Weekly |
| kyc-reminder | KYC prompts | Daily 11AM |

---

## Commands

```bash
pnpm dev              # Start all apps in dev mode
pnpm build            # Build all apps
pnpm test             # Run all tests
pnpm lint             # Lint all apps
pnpm typecheck        # TypeScript check all apps
pnpm db:generate      # Generate Drizzle migrations
pnpm db:migrate       # Run migrations
pnpm db:seed          # Seed initial data
pnpm db:studio        # Drizzle Studio UI
```

---

## License

Private — Zein Apps © 2024
