/**
 * SAWA — Database Seed Script
 * Run: pnpm db:seed
 */

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';
import { randomUUID } from 'crypto';
import 'dotenv/config';

const client = postgres(process.env['DATABASE_URL'] ?? '');
const db = drizzle(client, { schema });

async function seed(): Promise<void> {
  console.log('🌱 Starting database seed...');

  // ── 1. App Config (single row) ──────────────────────────────
  console.log('  → Seeding app_config...');
  await db
    .insert(schema.appConfig)
    .values({
      id: randomUUID(),
      minVersion: '1.0.0',
      latestVersion: '1.0.0',
      forceUpdate: false,
      maintenanceMode: false,
      maxWalletBalance: '100000.0000',
      confirmTransferLimit: '200.0000',
      maxDailyTransfer: '5000.0000',
      kycTriggerAmount: '500.0000',
      escrowAutoReleaseDays: 7,
      disputeReviewHours: 72,
      agentOtpExpiryMinutes: 30,
      agentMinTrustScore: 75,
      agentMinTransactions: 30,
      agentMinAccountAgeDays: 90,
      p2pFeePercent: '1.5',
      escrowFeePercent: '2.0',
      marketFeePercent: '1.0',
      agentFeePercent: '1.0',
      agentCommissionPercent: '0.5',
      premiumPriceSp: '500.0000',
      premiumTrialDays: 7,
      sponsored3DaysSp: '50.0000',
      sponsored7DaysSp: '100.0000',
      sponsored14DaysSp: '180.0000',
      aiQueriesFreeDaily: 20,
      aiQueriesPremiumDaily: 100,
      trustInitialScore: 60,
      trustFreezeThreshold: 5,
      trustWarningThreshold: 10,
      adminIpWhitelist: [],
    })
    .onConflictDoNothing();

  // ── 2. Exchange Rates ────────────────────────────────────────
  console.log('  → Seeding exchange_rates...');
  await db
    .insert(schema.exchangeRates)
    .values({
      id: randomUUID(),
      spToSyp: '100.0000',
      spToUsd: '0.03000000',
      spToEur: '0.02800000',
    })
    .onConflictDoNothing();

  // ── 3. Payment Methods ───────────────────────────────────────
  console.log('  → Seeding payment_methods...');
  const paymentMethods = [
    {
      id: randomUUID(),
      nameAr: 'شام كاش',
      nameEn: 'Sham Cash',
      type: 'both' as const,
      instructionsAr: 'حوّل المبلغ إلى حساب شام كاش الخاص بـ SAWA ثم ارفع صورة الإيصال.',
      instructionsEn: 'Transfer the amount to SAWA\'s Sham Cash account, then upload the receipt.',
      isActive: true,
      sortOrder: 1,
    },
    {
      id: randomUUID(),
      nameAr: 'سيرياتيل كاش',
      nameEn: 'Syriatel Cash',
      type: 'both' as const,
      instructionsAr: 'حوّل المبلغ إلى حساب سيرياتيل كاش الخاص بـ SAWA ثم ارفع صورة الإيصال.',
      instructionsEn: 'Transfer the amount to SAWA\'s Syriatel Cash account, then upload the receipt.',
      isActive: true,
      sortOrder: 2,
    },
    {
      id: randomUUID(),
      nameAr: 'USDT',
      nameEn: 'USDT (Tether)',
      type: 'both' as const,
      instructionsAr: 'أرسل USDT إلى عنوان المحفظة الخاص بـ SAWA (شبكة TRC20) ثم ارفع صورة المعاملة.',
      instructionsEn: 'Send USDT to SAWA\'s wallet address (TRC20 network), then upload the transaction screenshot.',
      isActive: true,
      sortOrder: 3,
    },
    {
      id: randomUUID(),
      nameAr: 'حوالة',
      nameEn: 'Hawala',
      type: 'both' as const,
      instructionsAr: 'تواصل مع وكيلنا المعتمد لإتمام عملية الحوالة ثم ارفع إيصال التأكيد.',
      instructionsEn: 'Contact our authorized agent to complete the hawala transfer, then upload the confirmation receipt.',
      isActive: true,
      sortOrder: 4,
    },
  ];

  for (const method of paymentMethods) {
    await db.insert(schema.paymentMethods).values(method).onConflictDoNothing();
  }

  // ── 4. Daily Missions ────────────────────────────────────────
  console.log('  → Seeding missions...');
  const missions = [
    {
      id: randomUUID(),
      titleAr: 'تسجيل الدخول اليومي',
      titleEn: 'Daily Login',
      descriptionAr: 'سجّل دخولك إلى SAWA اليوم',
      descriptionEn: 'Log in to SAWA today',
      rewardSp: '2.0000',
      missionType: 'login' as const,
      isActive: true,
    },
    {
      id: randomUUID(),
      titleAr: 'أتمم تحويلاً',
      titleEn: 'Complete a Transfer',
      descriptionAr: 'أرسل أي مبلغ لشخص آخر',
      descriptionEn: 'Send any amount to another user',
      rewardSp: '5.0000',
      missionType: 'transfer' as const,
      isActive: true,
    },
    {
      id: randomUUID(),
      titleAr: 'قيّم متعاملاً',
      titleEn: 'Rate a User',
      descriptionAr: 'أعطِ تقييماً لشخص تعاملت معه',
      descriptionEn: 'Give a rating to someone you dealt with',
      rewardSp: '3.0000',
      missionType: 'review' as const,
      isActive: true,
    },
    {
      id: randomUUID(),
      titleAr: 'أضف منشوراً',
      titleEn: 'Add a Post',
      descriptionAr: 'انشر خدمة أو منتجاً في السوق',
      descriptionEn: 'Post a service or product in the marketplace',
      rewardSp: '4.0000',
      missionType: 'post' as const,
      isActive: true,
    },
    {
      id: randomUUID(),
      titleAr: 'ساعد مستخدماً جديداً',
      titleEn: 'Help a New User',
      descriptionAr: 'أتمم معاملة مع مستخدم جديد',
      descriptionEn: 'Complete a transaction with a new user',
      rewardSp: '6.0000',
      missionType: 'help' as const,
      isActive: true,
    },
  ];

  for (const mission of missions) {
    await db.insert(schema.missions).values(mission).onConflictDoNothing();
  }

  // ── 5. System Ledger Accounts ────────────────────────────────
  console.log('  → Seeding system ledger accounts...');
  const systemAccounts = [
    { id: randomUUID(), type: 'system' as const, name: 'SAWA_FEES', isSystem: true },
    { id: randomUUID(), type: 'escrow' as const, name: 'SAWA_ESCROW', isSystem: true },
    { id: randomUUID(), type: 'system' as const, name: 'SAWA_RESERVE', isSystem: true },
  ];

  for (const account of systemAccounts) {
    await db
      .insert(schema.ledgerAccounts)
      .values({ ...account, balance: '0.0000', currency: 'SP' })
      .onConflictDoNothing();
  }

  console.log('✅ Seed completed successfully');
  await client.end();
  process.exit(0);
}

seed().catch((err) => {
  console.error('❌ Seed failed:', err);
  process.exit(1);
});
