/**
 * SAWA — Users & Auth Schema
 */

import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  integer,
  text,
  jsonb,
  uniqueIndex,
  index,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import {
  userRoleEnum,
  verificationLevelEnum,
  cardTypeEnum,
  cardColorEnum,
  currencyEnum,
  otpTypeEnum,
  deliveryStatusEnum,
  deviceTypeEnum,
} from './enums';

// ── Users ─────────────────────────────────────────────────────
export const users = pgTable(
  'users',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    fullName: varchar('full_name', { length: 100 }).notNull(),
    phone: varchar('phone', { length: 25 }),
    googleId: varchar('google_id', { length: 255 }),
    email: varchar('email', { length: 255 }),
    emailVerified: boolean('email_verified').default(false).notNull(),
    passwordHash: text('password_hash'),
    sawaId: varchar('sawa_id', { length: 20 }),           // SAWA-XXXX-XXXX
    username: varchar('username', { length: 30 }),         // ahmad.sawa
    role: userRoleEnum('role').default('user').notNull(),
    trustScore: integer('trust_score').default(60).notNull(),
    verificationLevel: verificationLevelEnum('verification_level')
      .default('basic')
      .notNull(),
    avatarUrl: text('avatar_url'),
    bio: text('bio'),
    isFrozen: boolean('is_frozen').default(false).notNull(),
    isDeleted: boolean('is_deleted').default(false).notNull(),
    deletedAt: timestamp('deleted_at'),
    termsAccepted: boolean('terms_accepted').default(false).notNull(),
    termsAcceptedAt: timestamp('terms_accepted_at'),
    preferredLanguage: varchar('preferred_language', { length: 5 })
      .default('ar')
      .notNull(),
    // Founder badge: set if user is among first 1000
    isFounder: boolean('is_founder').default(false).notNull(),
    // Metadata
    lastActiveAt: timestamp('last_active_at').defaultNow(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    phoneIdx: uniqueIndex('users_phone_idx').on(table.phone),
    emailIdx: uniqueIndex('users_email_idx').on(table.email),
    googleIdIdx: uniqueIndex('users_google_id_idx').on(table.googleId),
    sawaIdIdx: uniqueIndex('users_sawa_id_idx').on(table.sawaId),
    usernameIdx: uniqueIndex('users_username_idx').on(table.username),
    trustScoreIdx: index('users_trust_score_idx').on(table.trustScore),
    roleIdx: index('users_role_idx').on(table.role),
    createdAtIdx: index('users_created_at_idx').on(table.createdAt),
  }),
);

// ── Wallets ───────────────────────────────────────────────────
export const wallets = pgTable(
  'wallets',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    // Balances — NEVER go negative (enforced by DB constraint + application logic)
    availableBalance: varchar('available_balance', { length: 30 })
      .default('0.0000')
      .notNull(),
    frozenBalance: varchar('frozen_balance', { length: 30 })
      .default('0.0000')
      .notNull(),
    pendingBalance: varchar('pending_balance', { length: 30 })
      .default('0.0000')
      .notNull(),
    // Card — color is PERMANENT after onboarding
    cardType: cardTypeEnum('card_type').default('standard').notNull(),
    cardColor: cardColorEnum('card_color').notNull(),
    cardColorLocked: boolean('card_color_locked').default(true).notNull(),
    preferredCurrency: currencyEnum('preferred_currency').default('SP').notNull(),
    // Limits
    isFrozen: boolean('is_frozen').default(false).notNull(),
    dailyLimitSp: varchar('daily_limit_sp', { length: 20 }).default('5000.0000').notNull(),
    spendingLimitSp: varchar('spending_limit_sp', { length: 20 }),
    // Premium
    isPremium: boolean('is_premium').default(false).notNull(),
    premiumExpiresAt: timestamp('premium_expires_at'),
    premiumTrialUsed: boolean('premium_trial_used').default(false).notNull(),
    premiumTrialStartedAt: timestamp('premium_trial_started_at'),
    // Metadata
    totalTransactionsCount: integer('total_transactions_count').default(0).notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: uniqueIndex('wallets_user_id_idx').on(table.userId),
    isPremiumIdx: index('wallets_is_premium_idx').on(table.isPremium),
  }),
);

// ── Exchange Rates ────────────────────────────────────────────
export const exchangeRates = pgTable('exchange_rates', {
  id: uuid('id').primaryKey().defaultRandom(),
  spToSyp: varchar('sp_to_syp', { length: 20 }).notNull(),
  spToUsd: varchar('sp_to_usd', { length: 20 }).notNull(),
  spToEur: varchar('sp_to_eur', { length: 20 }).notNull(),
  updatedBy: uuid('updated_by').references(() => users.id, { onDelete: 'set null' }),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const exchangeHistory = pgTable(
  'exchange_history',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    spToSyp: varchar('sp_to_syp', { length: 20 }).notNull(),
    spToUsd: varchar('sp_to_usd', { length: 20 }).notNull(),
    spToEur: varchar('sp_to_eur', { length: 20 }).notNull(),
    changedBy: uuid('changed_by').references(() => users.id, { onDelete: 'set null' }),
    changedAt: timestamp('changed_at').defaultNow().notNull(),
  },
  (table) => ({
    changedAtIdx: index('exchange_history_changed_at_idx').on(table.changedAt),
  }),
);

// ── OTP Codes ─────────────────────────────────────────────────
export const otpCodes = pgTable(
  'otp_codes',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }),
    // Phone or email for unauthenticated OTPs
    identifier: varchar('identifier', { length: 255 }),
    // SHA256 hashed — NEVER plaintext
    codeHash: varchar('code_hash', { length: 64 }).notNull(),
    type: otpTypeEnum('type').notNull(),
    deliveryStatus: deliveryStatusEnum('delivery_status')
      .default('pending')
      .notNull(),
    deliveredAt: timestamp('delivered_at'),
    expiresAt: timestamp('expires_at').notNull(),
    attempts: integer('attempts').default(0).notNull(),
    isUsed: boolean('is_used').default(false).notNull(),
    usedAt: timestamp('used_at'),
    ipAddress: varchar('ip_address', { length: 45 }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userTypeIdx: index('otp_user_type_idx').on(table.userId, table.type),
    identifierTypeIdx: index('otp_identifier_type_idx').on(table.identifier, table.type),
    expiresAtIdx: index('otp_expires_at_idx').on(table.expiresAt),
  }),
);

// ── Sessions ──────────────────────────────────────────────────
export const sessions = pgTable(
  'sessions',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    // Refresh token — hashed (SHA256)
    refreshTokenHash: varchar('refresh_token_hash', { length: 64 }).notNull(),
    deviceFingerprint: varchar('device_fingerprint', { length: 255 }),
    deviceName: varchar('device_name', { length: 100 }),
    deviceOs: varchar('device_os', { length: 50 }),
    ipAddress: varchar('ip_address', { length: 45 }),
    city: varchar('city', { length: 100 }),
    country: varchar('country', { length: 100 }),
    expiresAt: timestamp('expires_at').notNull(),
    lastActiveAt: timestamp('last_active_at').defaultNow().notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('sessions_user_id_idx').on(table.userId),
    refreshTokenHashIdx: uniqueIndex('sessions_refresh_token_hash_idx').on(
      table.refreshTokenHash,
    ),
    expiresAtIdx: index('sessions_expires_at_idx').on(table.expiresAt),
  }),
);

// ── Device Tokens (FCM) ───────────────────────────────────────
export const deviceTokens = pgTable(
  'device_tokens',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    fcmToken: text('fcm_token').notNull(),
    deviceType: deviceTypeEnum('device_type').notNull(),
    deviceFingerprint: varchar('device_fingerprint', { length: 255 }),
    isActive: boolean('is_active').default(true).notNull(),
    lastActiveAt: timestamp('last_active_at').defaultNow().notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('device_tokens_user_id_idx').on(table.userId),
    fcmTokenIdx: uniqueIndex('device_tokens_fcm_token_idx').on(table.fcmToken),
  }),
);

// ── Idempotency Keys ──────────────────────────────────────────
export const idempotencyKeys = pgTable(
  'idempotency_keys',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    key: varchar('key', { length: 36 }).notNull(), // UUID format
    userId: uuid('user_id').references(() => users.id, { onDelete: 'cascade' }),
    endpoint: varchar('endpoint', { length: 200 }),
    requestHash: varchar('request_hash', { length: 64 }), // SHA256 of body
    response: jsonb('response'),
    statusCode: integer('status_code'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    expiresAt: timestamp('expires_at').notNull(), // 24 hours
  },
  (table) => ({
    keyIdx: uniqueIndex('idempotency_keys_key_idx').on(table.key),
    expiresAtIdx: index('idempotency_keys_expires_at_idx').on(table.expiresAt),
    userIdIdx: index('idempotency_keys_user_id_idx').on(table.userId),
  }),
);

// ── App Config (single row) ───────────────────────────────────
export const appConfig = pgTable('app_config', {
  id: uuid('id').primaryKey().defaultRandom(),
  // App Version
  minVersion: varchar('min_version', { length: 20 }).default('1.0.0').notNull(),
  latestVersion: varchar('latest_version', { length: 20 }).default('1.0.0').notNull(),
  forceUpdate: boolean('force_update').default(false).notNull(),
  // Maintenance
  maintenanceMode: boolean('maintenance_mode').default(false).notNull(),
  maintenanceMessageAr: text('maintenance_message_ar'),
  maintenanceMessageEn: text('maintenance_message_en'),
  maintenanceEndTime: timestamp('maintenance_end_time'),
  // Financial Limits
  maxWalletBalance: varchar('max_wallet_balance', { length: 20 }).default('100000').notNull(),
  confirmTransferLimit: varchar('confirm_transfer_limit', { length: 20 }).default('200').notNull(),
  maxDailyTransfer: varchar('max_daily_transfer', { length: 20 }).default('5000').notNull(),
  kycTriggerAmount: varchar('kyc_trigger_amount', { length: 20 }).default('500').notNull(),
  // Escrow
  escrowAutoReleaseDays: integer('escrow_auto_release_days').default(7).notNull(),
  disputeReviewHours: integer('dispute_review_hours').default(72).notNull(),
  // Agents
  agentOtpExpiryMinutes: integer('agent_otp_expiry_minutes').default(30).notNull(),
  agentMinTrustScore: integer('agent_min_trust_score').default(75).notNull(),
  agentMinTransactions: integer('agent_min_transactions').default(30).notNull(),
  agentMinAccountAgeDays: integer('agent_min_account_age_days').default(90).notNull(),
  // Commissions (stored as varchar to avoid floating point issues)
  p2pFeePercent: varchar('p2p_fee_percent', { length: 10 }).default('1.5').notNull(),
  escrowFeePercent: varchar('escrow_fee_percent', { length: 10 }).default('2.0').notNull(),
  marketFeePercent: varchar('market_fee_percent', { length: 10 }).default('1.0').notNull(),
  agentFeePercent: varchar('agent_fee_percent', { length: 10 }).default('1.0').notNull(),
  agentCommissionPercent: varchar('agent_commission_percent', { length: 10 }).default('0.5').notNull(),
  // Premium
  premiumPriceSp: varchar('premium_price_sp', { length: 20 }).default('500').notNull(),
  premiumTrialDays: integer('premium_trial_days').default(7).notNull(),
  // Sponsored
  sponsored3DaysSp: varchar('sponsored_3days_sp', { length: 20 }).default('50').notNull(),
  sponsored7DaysSp: varchar('sponsored_7days_sp', { length: 20 }).default('100').notNull(),
  sponsored14DaysSp: varchar('sponsored_14days_sp', { length: 20 }).default('180').notNull(),
  // AI Rate Limits
  aiQueriesFreeDaily: integer('ai_queries_free_daily').default(20).notNull(),
  aiQueriesPremiumDaily: integer('ai_queries_premium_daily').default(100).notNull(),
  // Trust Score
  trustInitialScore: integer('trust_initial_score').default(60).notNull(),
  trustFreezeThreshold: integer('trust_freeze_threshold').default(5).notNull(),
  trustWarningThreshold: integer('trust_warning_threshold').default(10).notNull(),
  // Admin
  adminIpWhitelist: jsonb('admin_ip_whitelist').$type<string[]>().default([]),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// ── Notification Settings ─────────────────────────────────────
export const notificationSettings = pgTable(
  'notification_settings',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    ratings: boolean('ratings').default(true).notNull(),
    missions: boolean('missions').default(true).notNull(),
    achievements: boolean('achievements').default(true).notNull(),
    marketOffers: boolean('market_offers').default(true).notNull(),
    neighborhood: boolean('neighborhood').default(true).notNull(),
    announcements: boolean('announcements').default(true).notNull(),
    chatMessages: boolean('chat_messages').default(true).notNull(),
    agentRequests: boolean('agent_requests').default(true).notNull(),
  },
  (table) => ({
    userIdIdx: uniqueIndex('notification_settings_user_id_idx').on(table.userId),
  }),
);

// ── Search History ────────────────────────────────────────────
export const searchHistory = pgTable(
  'search_history',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    query: varchar('query', { length: 200 }).notNull(),
    category: varchar('category', { length: 50 }),
    resultsCount: integer('results_count').default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('search_history_user_id_idx').on(table.userId, table.createdAt),
  }),
);

// ── Relations ─────────────────────────────────────────────────
export const usersRelations = relations(users, ({ one, many }) => ({
  wallet: one(wallets, { fields: [users.id], references: [wallets.userId] }),
  sessions: many(sessions),
  deviceTokens: many(deviceTokens),
  otpCodes: many(otpCodes),
  notificationSettings: one(notificationSettings, {
    fields: [users.id],
    references: [notificationSettings.userId],
  }),
  searchHistory: many(searchHistory),
}));

export const walletsRelations = relations(wallets, ({ one }) => ({
  user: one(users, { fields: [wallets.userId], references: [users.id] }),
}));

export const sessionsRelations = relations(sessions, ({ one }) => ({
  user: one(users, { fields: [sessions.userId], references: [users.id] }),
}));
