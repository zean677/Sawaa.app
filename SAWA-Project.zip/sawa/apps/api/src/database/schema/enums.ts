/**
 * SAWA — Database Enums
 * All PostgreSQL enums for the SAWA schema
 */

import { pgEnum } from 'drizzle-orm/pg-core';

// ── Users ─────────────────────────────────────────────────────
export const userRoleEnum = pgEnum('user_role', [
  'user',
  'agent',
  'moderator',
  'support',
  'admin',
  'super_admin',
]);

export const verificationLevelEnum = pgEnum('verification_level', [
  'basic',
  'verified',
  'trusted',
  'elite',
]);

// ── Cards ─────────────────────────────────────────────────────
export const cardTypeEnum = pgEnum('card_type', [
  'standard',
  'gold',
  'platinum',
  'founder',
  'diamond',
]);

export const cardColorEnum = pgEnum('card_color', [
  'silver',
  'gold',
  'black',
  'violet',    // Electric Violet #8B5CF6 — Founder
  'neon_blue', // Diamond
]);

// ── Finance ───────────────────────────────────────────────────
export const currencyEnum = pgEnum('currency', ['SP', 'SYP', 'USD', 'EUR']);

export const accountTypeEnum = pgEnum('account_type', [
  'asset',
  'liability',
  'escrow',
  'fee',
  'system',
]);

export const entryTypeEnum = pgEnum('entry_type', [
  'debit',
  'credit',
  'hold',
  'release',
  'refund',
  'fee',
  'reversal',
  'mission_reward',
]);

export const txTypeEnum = pgEnum('tx_type', [
  'deposit',
  'withdrawal',
  'transfer',
  'escrow_hold',
  'escrow_release',
  'escrow_refund',
  'agent',
  'agent_commission',
  'qr',
  'premium',
  'premium_gift',
  'boost',
  'refund',
  'mission_reward',
  'reversal',
]);

export const txStatusEnum = pgEnum('tx_status', [
  'pending',
  'completed',
  'failed',
  'refunded',
  'cancelled',
]);

// ── Escrow ────────────────────────────────────────────────────
export const escrowStatusEnum = pgEnum('escrow_status', [
  'pending',
  'completed',
  'refunded',
  'disputed',
  'expired',
  'cancelled',
]);

// ── Market ────────────────────────────────────────────────────
export const postCategoryEnum = pgEnum('post_category', [
  'service',
  'barter',
  'food',
  'rental',
  'digital',
  'job',
  'car',
  'real_estate',
  'electronics',
  'clothes',
  'books',
  'tools',
  'energy',
  'spare_parts',
  'auction',
  'freelance',
]);

export const postStatusEnum = pgEnum('post_status', [
  'draft',
  'active',
  'closed',
  'suspended',
  'expired',
]);

export const locationPrecisionEnum = pgEnum('location_precision', [
  'exact',
  'approximate',
  'hidden',
]);

// ── Agents ────────────────────────────────────────────────────
export const agentStatusEnum = pgEnum('agent_status', [
  'pending',
  'active',
  'suspended',
  'rejected',
]);

export const operationStatusEnum = pgEnum('operation_status', [
  'pending',
  'completed',
  'expired',
  'disputed',
  'cancelled',
]);

// ── Deposits ──────────────────────────────────────────────────
export const depositStatusEnum = pgEnum('deposit_status', [
  'pending',
  'under_review',
  'approved',
  'rejected',
  'cancelled',
]);

export const paymentDirectionEnum = pgEnum('payment_direction', [
  'deposit',
  'withdrawal',
  'both',
]);

// ── Auth ──────────────────────────────────────────────────────
export const otpTypeEnum = pgEnum('otp_type', [
  'login',
  'verify_email',
  'change_phone',
  'change_password',
  'agent_withdrawal',
  'delete_account',
  'recovery',
]);

export const deliveryStatusEnum = pgEnum('delivery_status', [
  'pending',
  'sent',
  'delivered',
  'failed',
]);

export const deviceTypeEnum = pgEnum('device_type', [
  'ios',
  'android',
  'web',
]);

// ── Chat ──────────────────────────────────────────────────────
export const messageTypeEnum = pgEnum('message_type', [
  'text',
  'image',
  'audio',
  'location',
  'post_share',
  'system',
]);

// ── Social ────────────────────────────────────────────────────
export const badgeTypeEnum = pgEnum('badge_type', [
  'verified',
  'founder',
  'top_seller',
  'community_hero',
  'fast_responder',
  'escrow_safe',
  'trusted_agent',
  'premium_member',
  'diamond_seller',
  'power_user',
]);

export const clubCategoryEnum = pgEnum('club_category', [
  'students',
  'developers',
  'traders',
  'doctors',
  'kitchens',
  'electricians',
  'freelancers',
  'farmers',
  'official',
  'general',
]);

export const clubRoleEnum = pgEnum('club_role', ['admin', 'member']);

export const missionTypeEnum = pgEnum('mission_type', [
  'login',
  'transfer',
  'review',
  'post',
  'help',
  'escrow',
]);

// ── Notifications ─────────────────────────────────────────────
export const notificationTypeEnum = pgEnum('notification_type', [
  'transfer_received',
  'escrow_update',
  'dispute_opened',
  'security_alert',
  'new_device',
  'new_rating',
  'daily_mission',
  'achievement',
  'market_offer',
  'post_expiring',
  'premium_expiring',
  'premium_renewed',
  'deposit_approved',
  'deposit_rejected',
  'announcement',
  'agent_request',
  'escrow_auto_release_warning',
  'escrow_expiry_warning',
  'account_frozen',
  'trust_score_warning',
  'kyc_required',
]);

// ── Reports ───────────────────────────────────────────────────
export const reportTargetEnum = pgEnum('report_target', [
  'user',
  'post',
  'message',
]);

export const reportReasonEnum = pgEnum('report_reason', [
  'fraud',
  'spam',
  'inappropriate',
  'fake',
  'harassment',
  'other',
]);

export const reportStatusEnum = pgEnum('report_status', [
  'pending',
  'reviewed',
  'actioned',
  'dismissed',
]);

// ── System ────────────────────────────────────────────────────
export const freezeReasonEnum = pgEnum('freeze_reason', [
  'escrow',
  'kyc',
  'dispute',
  'admin',
  'agent_withdrawal',
  'suspicious_activity',
]);

export const jobStatusEnum = pgEnum('job_status', [
  'running',
  'completed',
  'failed',
  'partial',
]);

export const favoriteTypeEnum = pgEnum('favorite_type', ['post', 'user']);
