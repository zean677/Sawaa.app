/**
 * SAWA — Financial Schema
 * Ledger, Transactions, Escrow, Deposits
 * All monetary values stored as varchar to avoid floating point issues
 */

import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  integer,
  text,
  jsonb,
  index,
  uniqueIndex,
} from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';
import { users, wallets } from './users';
import {
  accountTypeEnum,
  entryTypeEnum,
  txTypeEnum,
  txStatusEnum,
  escrowStatusEnum,
  depositStatusEnum,
  paymentDirectionEnum,
  freezeReasonEnum,
  jobStatusEnum,
  currencyEnum,
} from './enums';

// ── Ledger Accounts ───────────────────────────────────────────
export const ledgerAccounts = pgTable(
  'ledger_accounts',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id').references(() => users.id, { onDelete: 'restrict' }),
    type: accountTypeEnum('type').notNull(),
    // System accounts: SAWA_FEES, SAWA_ESCROW, SAWA_RESERVE
    name: varchar('name', { length: 100 }),
    balance: varchar('balance', { length: 30 }).default('0.0000').notNull(),
    currency: currencyEnum('currency').default('SP').notNull(),
    isSystem: boolean('is_system').default(false).notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('ledger_accounts_user_id_idx').on(table.userId),
    typeIdx: index('ledger_accounts_type_idx').on(table.type),
    isSystemIdx: index('ledger_accounts_is_system_idx').on(table.isSystem),
  }),
);

/**
 * Ledger Entries — IMMUTABLE (INSERT only, enforced by DB trigger)
 * Every financial operation creates at least 2 entries (debit + credit)
 * Sum(debits) MUST always equal Sum(credits) — enforced by reconciliation
 */
export const ledgerEntries = pgTable(
  'ledger_entries',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    transactionId: uuid('transaction_id')
      .references(() => transactions.id, { onDelete: 'restrict' })
      .notNull(),
    debitAccountId: uuid('debit_account_id')
      .references(() => ledgerAccounts.id, { onDelete: 'restrict' })
      .notNull(),
    creditAccountId: uuid('credit_account_id')
      .references(() => ledgerAccounts.id, { onDelete: 'restrict' })
      .notNull(),
    amount: varchar('amount', { length: 30 }).notNull(),
    currency: currencyEnum('currency').default('SP').notNull(),
    type: entryTypeEnum('type').notNull(),
    // Immutable flag — trigger enforces this
    isImmutable: boolean('is_immutable').default(true).notNull(),
    // Memo for human-readable audit
    memo: varchar('memo', { length: 255 }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    transactionIdIdx: index('ledger_entries_tx_id_idx').on(table.transactionId),
    debitAccountIdx: index('ledger_entries_debit_idx').on(table.debitAccountId),
    creditAccountIdx: index('ledger_entries_credit_idx').on(table.creditAccountId),
    createdAtIdx: index('ledger_entries_created_at_idx').on(table.createdAt),
    typeIdx: index('ledger_entries_type_idx').on(table.type),
  }),
);

/**
 * Transactions — The source of truth for all money movements
 * created_at is effectively immutable (never updated)
 */
export const transactions = pgTable(
  'transactions',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    senderId: uuid('sender_id').references(() => users.id, { onDelete: 'restrict' }),
    receiverId: uuid('receiver_id').references(() => users.id, { onDelete: 'restrict' }),
    amountSp: varchar('amount_sp', { length: 30 }).notNull(),
    feeSp: varchar('fee_sp', { length: 30 }).default('0.0000').notNull(),
    netAmountSp: varchar('net_amount_sp', { length: 30 }).notNull(),
    type: txTypeEnum('type').notNull(),
    status: txStatusEnum('status').default('pending').notNull(),
    // CRITICAL: Unique per financial operation — prevents double-spend on retry
    idempotencyKey: uuid('idempotency_key').notNull(),
    note: text('note'),
    // Links to escrow, agent_operation, etc.
    referenceId: uuid('reference_id'),
    referenceType: varchar('reference_type', { length: 50 }),
    // Exchange rate snapshot at time of transaction
    exchangeRate: jsonb('exchange_rate'),
    metadata: jsonb('metadata'),
    // For cancellable transfers (30s window)
    cancelableUntil: timestamp('cancelable_until'),
    canceledAt: timestamp('canceled_at'),
    canceledBy: uuid('canceled_by').references(() => users.id),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    senderIdx: index('transactions_sender_idx').on(table.senderId, table.createdAt),
    receiverIdx: index('transactions_receiver_idx').on(table.receiverId, table.createdAt),
    idempotencyIdx: uniqueIndex('transactions_idempotency_idx').on(table.idempotencyKey),
    statusIdx: index('transactions_status_idx').on(table.status),
    typeIdx: index('transactions_type_idx').on(table.type),
    referenceIdx: index('transactions_reference_idx').on(table.referenceId),
    createdAtIdx: index('transactions_created_at_idx').on(table.createdAt),
  }),
);

// ── Balance Snapshots (daily 3AM) ─────────────────────────────
export const balanceSnapshots = pgTable(
  'balance_snapshots',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    availableBalance: varchar('available_balance', { length: 30 }).notNull(),
    frozenBalance: varchar('frozen_balance', { length: 30 }).notNull(),
    pendingBalance: varchar('pending_balance', { length: 30 }).notNull(),
    snapshotDate: varchar('snapshot_date', { length: 10 }).notNull(), // YYYY-MM-DD
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userDateIdx: uniqueIndex('balance_snapshots_user_date_idx').on(
      table.userId,
      table.snapshotDate,
    ),
    snapshotDateIdx: index('balance_snapshots_date_idx').on(table.snapshotDate),
  }),
);

// ── Frozen Balances ────────────────────────────────────────────
export const frozenBalances = pgTable(
  'frozen_balances',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    amount: varchar('amount', { length: 30 }).notNull(),
    reason: freezeReasonEnum('reason').notNull(),
    referenceId: uuid('reference_id'),
    referenceType: varchar('reference_type', { length: 50 }),
    isReleased: boolean('is_released').default(false).notNull(),
    releasedAt: timestamp('released_at'),
    releaseTransactionId: uuid('release_transaction_id').references(
      () => transactions.id,
    ),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('frozen_balances_user_id_idx').on(table.userId),
    referenceIdx: index('frozen_balances_reference_idx').on(table.referenceId),
    isReleasedIdx: index('frozen_balances_is_released_idx').on(table.isReleased),
  }),
);

// ── Transaction Locks (short TTL — prevents race conditions) ──
export const transactionLocks = pgTable(
  'transaction_locks',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    lockKey: varchar('lock_key', { length: 100 }).notNull(),
    expiresAt: timestamp('expires_at').notNull(), // 30 seconds TTL
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    lockKeyIdx: uniqueIndex('transaction_locks_key_idx').on(table.lockKey),
    expiresAtIdx: index('transaction_locks_expires_at_idx').on(table.expiresAt),
    userIdIdx: index('transaction_locks_user_id_idx').on(table.userId),
  }),
);

// ── Reconciliation Jobs ───────────────────────────────────────
export const reconciliationJobs = pgTable(
  'reconciliation_jobs',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    status: jobStatusEnum('status').notNull(),
    totalUsersChecked: integer('total_users_checked').default(0).notNull(),
    discrepanciesFound: integer('discrepancies_found').default(0).notNull(),
    details: jsonb('details').$type<{
      discrepancies: Array<{
        userId: string;
        walletBalance: string;
        ledgerBalance: string;
        difference: string;
      }>;
    }>(),
    ranAt: timestamp('ran_at').defaultNow().notNull(),
    completedAt: timestamp('completed_at'),
    durationMs: integer('duration_ms'),
  },
  (table) => ({
    ranAtIdx: index('reconciliation_jobs_ran_at_idx').on(table.ranAt),
    statusIdx: index('reconciliation_jobs_status_idx').on(table.status),
  }),
);

// ── Escrow ────────────────────────────────────────────────────
export const escrow = pgTable(
  'escrow',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    buyerId: uuid('buyer_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    sellerId: uuid('seller_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    amountSp: varchar('amount_sp', { length: 30 }).notNull(),
    feeSp: varchar('fee_sp', { length: 30 }).default('0.0000').notNull(),
    netAmountSp: varchar('net_amount_sp', { length: 30 }).notNull(),
    status: escrowStatusEnum('status').default('pending').notNull(),
    description: text('description').notNull(),
    // Milestones: [{id, title, amount_sp, status, deadline, released_at}]
    milestones: jsonb('milestones').$type<
      Array<{
        id: string;
        title: string;
        amountSp: string;
        status: 'pending' | 'completed' | 'disputed';
        deadline: string | null;
        releasedAt: string | null;
      }>
    >(),
    // Dispute
    disputeOpenedAt: timestamp('dispute_opened_at'),
    disputeOpenedBy: uuid('dispute_opened_by').references(() => users.id),
    disputeResolvedAt: timestamp('dispute_resolved_at'),
    disputeResolvedBy: uuid('dispute_resolved_by').references(() => users.id),
    disputeResolution: text('dispute_resolution'),
    // Auto-release
    autoReleaseAt: timestamp('auto_release_at'),
    releaseWarningSent: boolean('release_warning_sent').default(false).notNull(),
    // Expiry
    expiryWarningSent: boolean('expiry_warning_sent').default(false).notNull(),
    deadline: timestamp('deadline'),
    // Cancellation
    cancellationRequestedBy: uuid('cancellation_requested_by').references(() => users.id),
    cancellationRequestedAt: timestamp('cancellation_requested_at'),
    // Linked transaction IDs
    holdTransactionId: uuid('hold_transaction_id').references(() => transactions.id),
    releaseTransactionId: uuid('release_transaction_id').references(() => transactions.id),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    buyerStatusIdx: index('escrow_buyer_status_idx').on(table.buyerId, table.status),
    sellerStatusIdx: index('escrow_seller_status_idx').on(table.sellerId, table.status),
    autoReleaseIdx: index('escrow_auto_release_idx').on(table.autoReleaseAt, table.status),
    statusIdx: index('escrow_status_idx').on(table.status),
    deadlineIdx: index('escrow_deadline_idx').on(table.deadline),
    createdAtIdx: index('escrow_created_at_idx').on(table.createdAt),
  }),
);

// ── Payment Methods ───────────────────────────────────────────
export const paymentMethods = pgTable('payment_methods', {
  id: uuid('id').primaryKey().defaultRandom(),
  nameAr: varchar('name_ar', { length: 100 }).notNull(),
  nameEn: varchar('name_en', { length: 100 }).notNull(),
  type: paymentDirectionEnum('type').default('both').notNull(),
  logoUrl: text('logo_url'),
  instructionsAr: text('instructions_ar'),
  instructionsEn: text('instructions_en'),
  minAmountSp: varchar('min_amount_sp', { length: 20 }),
  maxAmountSp: varchar('max_amount_sp', { length: 20 }),
  isActive: boolean('is_active').default(true).notNull(),
  sortOrder: integer('sort_order').default(0).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

// ── Deposit Requests ──────────────────────────────────────────
export const depositRequests = pgTable(
  'deposit_requests',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    paymentMethodId: uuid('payment_method_id')
      .references(() => paymentMethods.id)
      .notNull(),
    // Amount requested by user
    amountSp: varchar('amount_sp', { length: 30 }).notNull(),
    // Actual amount confirmed by admin (may differ)
    actualAmountSp: varchar('actual_amount_sp', { length: 30 }),
    // Watermarked proof image (R2 URL)
    proofImageUrl: text('proof_image_url').notNull(),
    status: depositStatusEnum('status').default('pending').notNull(),
    reviewedBy: uuid('reviewed_by').references(() => users.id),
    rejectionReason: text('rejection_reason'),
    transactionId: uuid('transaction_id').references(() => transactions.id),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    reviewedAt: timestamp('reviewed_at'),
  },
  (table) => ({
    userIdIdx: index('deposit_requests_user_id_idx').on(table.userId),
    statusIdx: index('deposit_requests_status_idx').on(table.status),
    createdAtIdx: index('deposit_requests_created_at_idx').on(table.createdAt),
  }),
);

// ── Relations ─────────────────────────────────────────────────
export const transactionsRelations = relations(transactions, ({ one, many }) => ({
  sender: one(users, { fields: [transactions.senderId], references: [users.id], relationName: 'sent_transactions' }),
  receiver: one(users, { fields: [transactions.receiverId], references: [users.id], relationName: 'received_transactions' }),
  ledgerEntries: many(ledgerEntries),
}));

export const escrowRelations = relations(escrow, ({ one }) => ({
  buyer: one(users, { fields: [escrow.buyerId], references: [users.id], relationName: 'buyer_escrows' }),
  seller: one(users, { fields: [escrow.sellerId], references: [users.id], relationName: 'seller_escrows' }),
  holdTransaction: one(transactions, { fields: [escrow.holdTransactionId], references: [transactions.id] }),
}));

export const ledgerEntriesRelations = relations(ledgerEntries, ({ one }) => ({
  transaction: one(transactions, { fields: [ledgerEntries.transactionId], references: [transactions.id] }),
  debitAccount: one(ledgerAccounts, { fields: [ledgerEntries.debitAccountId], references: [ledgerAccounts.id] }),
  creditAccount: one(ledgerAccounts, { fields: [ledgerEntries.creditAccountId], references: [ledgerAccounts.id] }),
}));
