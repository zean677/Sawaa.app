/**
 * SAWA — Market, Agents, Chat, Social Schema
 */

import {
  pgTable,
  uuid,
  varchar,
  boolean,
  timestamp,
  integer,
  text,
  jsonb,
  index,
  uniqueIndex,
  geometry,
  primaryKey,
} from 'drizzle-orm/pg-core';
import { relations, sql } from 'drizzle-orm';
import { users } from './users';
import { escrow, transactions } from './financial';
import {
  postCategoryEnum,
  postStatusEnum,
  locationPrecisionEnum,
  agentStatusEnum,
  operationStatusEnum,
  messageTypeEnum,
  badgeTypeEnum,
  clubCategoryEnum,
  clubRoleEnum,
  missionTypeEnum,
  notificationTypeEnum,
  reportTargetEnum,
  reportReasonEnum,
  reportStatusEnum,
  favoriteTypeEnum,
} from './enums';

// ══════════════════════════════════════════════════════════════
// MARKETPLACE
// ══════════════════════════════════════════════════════════════

export const marketPosts = pgTable(
  'market_posts',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    title: varchar('title', { length: 200 }).notNull(),
    description: text('description').notNull(),
    category: postCategoryEnum('category').notNull(),
    priceSp: varchar('price_sp', { length: 30 }),
    priceOnRequest: boolean('price_on_request').default(false).notNull(),
    exchangeFor: text('exchange_for'),
    // R2 URLs — 5 free / 10 premium
    images: jsonb('images').$type<string[]>().default([]).notNull(),
    // PostGIS geometry — stored as WKT or use custom type
    locationLat: varchar('location_lat', { length: 20 }),
    locationLng: varchar('location_lng', { length: 20 }),
    address: text('address'),
    city: varchar('city', { length: 100 }),
    locationPrecision: locationPrecisionEnum('location_precision')
      .default('approximate')
      .notNull(),
    status: postStatusEnum('status').default('active').notNull(),
    viewsCount: integer('views_count').default(0).notNull(),
    contactsCount: integer('contacts_count').default(0).notNull(),
    escrowEnabled: boolean('escrow_enabled').default(true).notNull(),
    // Sponsored
    isSponsored: boolean('is_sponsored').default(false).notNull(),
    sponsoredUntil: timestamp('sponsored_until'),
    sponsorTransactionId: uuid('sponsor_transaction_id').references(() => transactions.id),
    // Limits
    renewalCount: integer('renewal_count').default(0).notNull(),
    updateCount: integer('update_count').default(0).notNull(),
    expiresAt: timestamp('expires_at').notNull(),
    isExpired: boolean('is_expired').default(false).notNull(),
    expiryNotificationSent: boolean('expiry_notification_sent').default(false).notNull(),
    // Metadata
    tags: jsonb('tags').$type<string[]>().default([]),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    userStatusIdx: index('market_posts_user_status_idx').on(table.userId, table.status),
    categoryStatusIdx: index('market_posts_category_status_idx').on(table.category, table.status),
    expiresAtIdx: index('market_posts_expires_at_idx').on(table.expiresAt, table.status),
    sponsoredIdx: index('market_posts_sponsored_idx').on(table.isSponsored, table.sponsoredUntil),
    cityIdx: index('market_posts_city_idx').on(table.city),
    createdAtIdx: index('market_posts_created_at_idx').on(table.createdAt),
    // Composite for listing order algorithm
    listingOrderIdx: index('market_posts_listing_order_idx').on(
      table.isSponsored,
      table.status,
      table.createdAt,
    ),
  }),
);

// Post views — Redis SET for real-time, DB for persistence
export const postViews = pgTable(
  'post_views',
  {
    postId: uuid('post_id')
      .references(() => marketPosts.id, { onDelete: 'cascade' })
      .notNull(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    viewedAt: timestamp('viewed_at').defaultNow().notNull(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.postId, table.userId] }),
    postIdIdx: index('post_views_post_id_idx').on(table.postId),
  }),
);

// ══════════════════════════════════════════════════════════════
// AGENTS
// ══════════════════════════════════════════════════════════════

export const agents = pgTable(
  'agents',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    locationLat: varchar('location_lat', { length: 20 }),
    locationLng: varchar('location_lng', { length: 20 }),
    coverageArea: text('coverage_area'),
    city: varchar('city', { length: 100 }),
    maxCashLimitSp: varchar('max_cash_limit_sp', { length: 20 }).notNull(),
    // {mon:{open:'08:00',close:'22:00'}, ...}
    workingHours: jsonb('working_hours').$type<
      Record<string, { open: string; close: string } | null>
    >(),
    isAvailable: boolean('is_available').default(false).notNull(),
    totalOperations: integer('total_operations').default(0).notNull(),
    commissionEarnedSp: varchar('commission_earned_sp', { length: 30 })
      .default('0.0000')
      .notNull(),
    ratingAverage: varchar('rating_average', { length: 5 }).default('0').notNull(),
    ratingCount: integer('rating_count').default(0).notNull(),
    status: agentStatusEnum('status').default('pending').notNull(),
    hasVerificationBadge: boolean('has_verification_badge').default(false).notNull(),
    approvedBy: uuid('approved_by').references(() => users.id),
    approvedAt: timestamp('approved_at'),
    rejectedBy: uuid('rejected_by').references(() => users.id),
    rejectedAt: timestamp('rejected_at'),
    rejectionReason: text('rejection_reason'),
    suspendedBy: uuid('suspended_by').references(() => users.id),
    suspendedAt: timestamp('suspended_at'),
    suspensionReason: text('suspension_reason'),
    applicationData: jsonb('application_data'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: uniqueIndex('agents_user_id_idx').on(table.userId),
    availableStatusIdx: index('agents_available_status_idx').on(
      table.isAvailable,
      table.status,
    ),
    cityIdx: index('agents_city_idx').on(table.city),
    statusIdx: index('agents_status_idx').on(table.status),
  }),
);

export const agentOperations = pgTable(
  'agent_operations',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    agentId: uuid('agent_id')
      .references(() => agents.id, { onDelete: 'restrict' })
      .notNull(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    amountSp: varchar('amount_sp', { length: 30 }).notNull(),
    amountSyp: varchar('amount_syp', { length: 30 }),
    // SHA256 hashed OTP — NEVER plaintext
    otpHash: varchar('otp_hash', { length: 64 }).notNull(),
    otpExpiresAt: timestamp('otp_expires_at').notNull(),
    status: operationStatusEnum('status').default('pending').notNull(),
    commissionSp: varchar('commission_sp', { length: 30 }),
    feeSp: varchar('fee_sp', { length: 30 }),
    completedAt: timestamp('completed_at'),
    // Frozen balance reference
    frozenBalanceId: uuid('frozen_balance_id'),
    transactionId: uuid('transaction_id').references(() => transactions.id),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    agentIdIdx: index('agent_operations_agent_id_idx').on(table.agentId, table.status),
    userIdIdx: index('agent_operations_user_id_idx').on(table.userId),
    otpExpiresIdx: index('agent_operations_otp_expires_idx').on(table.otpExpiresAt, table.status),
    statusIdx: index('agent_operations_status_idx').on(table.status),
  }),
);

// ══════════════════════════════════════════════════════════════
// CHAT
// ══════════════════════════════════════════════════════════════

export const chatRooms = pgTable(
  'chat_rooms',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userOneId: uuid('user_one_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    userTwoId: uuid('user_two_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    // Links
    escrowId: uuid('escrow_id').references(() => escrow.id),
    postId: uuid('post_id').references(() => marketPosts.id),
    // State
    isLocked: boolean('is_locked').default(false).notNull(),
    // Locked as legal evidence after dispute opened
    isEvidence: boolean('is_evidence').default(false).notNull(),
    lastMessageAt: timestamp('last_message_at'),
    lastMessagePreview: varchar('last_message_preview', { length: 100 }),
    // Unread counts
    unreadCountOne: integer('unread_count_one').default(0).notNull(),
    unreadCountTwo: integer('unread_count_two').default(0).notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    usersIdx: uniqueIndex('chat_rooms_users_idx').on(table.userOneId, table.userTwoId),
    escrowIdx: index('chat_rooms_escrow_idx').on(table.escrowId),
    lastMsgIdx: index('chat_rooms_last_message_idx').on(table.lastMessageAt),
  }),
);

export const chatMessages = pgTable(
  'chat_messages',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    roomId: uuid('room_id')
      .references(() => chatRooms.id, { onDelete: 'restrict' })
      .notNull(),
    senderId: uuid('sender_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    type: messageTypeEnum('type').notNull(),
    content: text('content'),
    // For images/audio: R2 URL; for location: {lat, lng, address}; for post_share: {postId,...}
    metadata: jsonb('metadata'),
    isRead: boolean('is_read').default(false).notNull(),
    readAt: timestamp('read_at'),
    // AI moderation
    isFlagged: boolean('is_flagged').default(false).notNull(),
    flagReason: varchar('flag_reason', { length: 100 }),
    // Soft delete — 5-minute window
    isDeleted: boolean('is_deleted').default(false).notNull(),
    deletedAt: timestamp('deleted_at'),
    canDeleteUntil: timestamp('can_delete_until'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    roomCreatedIdx: index('chat_messages_room_created_idx').on(table.roomId, table.createdAt),
    senderIdx: index('chat_messages_sender_idx').on(table.senderId),
    isFlaggedIdx: index('chat_messages_flagged_idx').on(table.isFlagged),
  }),
);

// Chat violation tracking
export const chatViolations = pgTable(
  'chat_violations',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    roomId: uuid('room_id').references(() => chatRooms.id),
    messageId: uuid('message_id').references(() => chatMessages.id),
    violationType: varchar('violation_type', { length: 50 }).notNull(),
    severity: varchar('severity', { length: 20 }).default('medium').notNull(),
    action: varchar('action', { length: 50 }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('chat_violations_user_id_idx').on(table.userId, table.createdAt),
  }),
);

// Muted chats
export const mutedChats = pgTable(
  'muted_chats',
  {
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    roomId: uuid('room_id')
      .references(() => chatRooms.id, { onDelete: 'cascade' })
      .notNull(),
    mutedUntil: timestamp('muted_until'), // null = forever
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.userId, table.roomId] }),
  }),
);

// ══════════════════════════════════════════════════════════════
// SOCIAL
// ══════════════════════════════════════════════════════════════

export const ratings = pgTable(
  'ratings',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    reviewerId: uuid('reviewer_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    reviewedId: uuid('reviewed_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    escrowId: uuid('escrow_id').references(() => escrow.id),
    isAgentRating: boolean('is_agent_rating').default(false).notNull(),
    // 4 criteria 1-5
    quality: integer('quality').notNull(),
    speed: integer('speed').notNull(),
    honesty: integer('honesty').notNull(),
    communication: integer('communication').notNull(),
    // Computed average (stored for query efficiency)
    average: varchar('average', { length: 5 }).notNull(),
    comment: text('comment'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    reviewedIdx: index('ratings_reviewed_id_idx').on(table.reviewedId),
    reviewerReviewedIdx: index('ratings_reviewer_reviewed_idx').on(
      table.reviewerId,
      table.reviewedId,
    ),
    escrowIdx: index('ratings_escrow_id_idx').on(table.escrowId),
  }),
);

export const badges = pgTable(
  'badges',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    badgeType: badgeTypeEnum('badge_type').notNull(),
    earnedAt: timestamp('earned_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('badges_user_id_idx').on(table.userId),
    userBadgeIdx: uniqueIndex('badges_user_badge_idx').on(table.userId, table.badgeType),
  }),
);

export const trustScoreHistory = pgTable(
  'trust_score_history',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    scoreAfter: integer('score_after').notNull(),
    change: integer('change').notNull(),
    reason: varchar('reason', { length: 200 }),
    triggeredBy: varchar('triggered_by', { length: 100 }),
    metadata: jsonb('metadata'),
    recordedAt: timestamp('recorded_at').defaultNow().notNull(),
  },
  (table) => ({
    userIdIdx: index('trust_history_user_id_idx').on(table.userId, table.recordedAt),
  }),
);

export const clubs = pgTable(
  'clubs',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    name: varchar('name', { length: 100 }).notNull(),
    category: clubCategoryEnum('category').notNull(),
    description: text('description'),
    coverImageUrl: text('cover_image_url'),
    createdBy: uuid('created_by')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    isOfficial: boolean('is_official').default(false).notNull(),
    membersCount: integer('members_count').default(0).notNull(),
    city: varchar('city', { length: 100 }),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => ({
    categoryIdx: index('clubs_category_idx').on(table.category),
    isOfficialIdx: index('clubs_is_official_idx').on(table.isOfficial),
    cityIdx: index('clubs_city_idx').on(table.city),
  }),
);

export const clubMembers = pgTable(
  'club_members',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    clubId: uuid('club_id')
      .references(() => clubs.id, { onDelete: 'cascade' })
      .notNull(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    role: clubRoleEnum('role').default('member').notNull(),
    joinedAt: timestamp('joined_at').defaultNow().notNull(),
  },
  (table) => ({
    clubUserIdx: uniqueIndex('club_members_club_user_idx').on(table.clubId, table.userId),
    userIdIdx: index('club_members_user_id_idx').on(table.userId),
  }),
);

export const missions = pgTable('missions', {
  id: uuid('id').primaryKey().defaultRandom(),
  titleAr: varchar('title_ar', { length: 200 }).notNull(),
  titleEn: varchar('title_en', { length: 200 }).notNull(),
  descriptionAr: text('description_ar'),
  descriptionEn: text('description_en'),
  rewardSp: varchar('reward_sp', { length: 20 }).notNull(),
  missionType: missionTypeEnum('mission_type').notNull(),
  isActive: boolean('is_active').default(true).notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const userMissions = pgTable(
  'user_missions',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    missionId: uuid('mission_id')
      .references(() => missions.id, { onDelete: 'cascade' })
      .notNull(),
    completedAt: timestamp('completed_at').defaultNow().notNull(),
    rewardClaimed: boolean('reward_claimed').default(false).notNull(),
    rewardTransactionId: uuid('reward_transaction_id').references(() => transactions.id),
    completionDate: varchar('completion_date', { length: 10 }).notNull(), // YYYY-MM-DD for daily reset
  },
  (table) => ({
    userDailyMissionIdx: uniqueIndex('user_missions_user_daily_idx').on(
      table.userId,
      table.missionId,
      table.completionDate,
    ),
    userIdIdx: index('user_missions_user_id_idx').on(table.userId),
  }),
);

// ══════════════════════════════════════════════════════════════
// SYSTEM
// ══════════════════════════════════════════════════════════════

export const notifications = pgTable(
  'notifications',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    type: notificationTypeEnum('type').notNull(),
    titleAr: text('title_ar').notNull(),
    titleEn: text('title_en').notNull(),
    bodyAr: text('body_ar').notNull(),
    bodyEn: text('body_en').notNull(),
    // Deep link params for navigation
    data: jsonb('data'),
    isRead: boolean('is_read').default(false).notNull(),
    readAt: timestamp('read_at'),
    // auto-delete after 30 days
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userCreatedIdx: index('notifications_user_created_idx').on(
      table.userId,
      table.createdAt,
    ),
    isReadIdx: index('notifications_is_read_idx').on(table.userId, table.isRead),
  }),
);

export const reports = pgTable(
  'reports',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    reporterId: uuid('reporter_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    targetType: reportTargetEnum('target_type').notNull(),
    targetId: uuid('target_id').notNull(),
    reason: reportReasonEnum('reason').notNull(),
    description: text('description'),
    status: reportStatusEnum('status').default('pending').notNull(),
    reviewedBy: uuid('reviewed_by').references(() => users.id),
    reviewNote: text('review_note'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    reviewedAt: timestamp('reviewed_at'),
  },
  (table) => ({
    targetIdx: index('reports_target_idx').on(table.targetType, table.targetId),
    statusIdx: index('reports_status_idx').on(table.status),
    reporterIdx: index('reports_reporter_idx').on(table.reporterId),
  }),
);

export const favorites = pgTable(
  'favorites',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    userId: uuid('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    targetType: favoriteTypeEnum('target_type').notNull(),
    targetId: uuid('target_id').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    userTypeIdx: uniqueIndex('favorites_user_type_target_idx').on(
      table.userId,
      table.targetType,
      table.targetId,
    ),
    userIdx: index('favorites_user_idx').on(table.userId),
  }),
);

export const blocks = pgTable(
  'blocks',
  {
    blockerId: uuid('blocker_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    blockedId: uuid('blocked_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    pk: primaryKey({ columns: [table.blockerId, table.blockedId] }),
    blockerIdx: index('blocks_blocker_idx').on(table.blockerId),
    blockedIdx: index('blocks_blocked_idx').on(table.blockedId),
  }),
);

// Immutable audit log — DB trigger prevents UPDATE/DELETE
export const auditLog = pgTable(
  'audit_log',
  {
    id: uuid('id').primaryKey().defaultRandom(),
    adminId: uuid('admin_id')
      .references(() => users.id, { onDelete: 'restrict' })
      .notNull(),
    action: varchar('action', { length: 200 }).notNull(),
    targetType: varchar('target_type', { length: 50 }),
    targetId: uuid('target_id'),
    details: jsonb('details'),
    ipAddress: varchar('ip_address', { length: 45 }),
    userAgent: text('user_agent'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => ({
    adminIdIdx: index('audit_log_admin_id_idx').on(table.adminId),
    targetIdx: index('audit_log_target_idx').on(table.targetType, table.targetId),
    createdAtIdx: index('audit_log_created_at_idx').on(table.createdAt),
  }),
);
