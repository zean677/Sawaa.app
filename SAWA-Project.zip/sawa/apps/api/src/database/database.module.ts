/**
 * SAWA — Database Module
 * Drizzle ORM + PostgreSQL with connection pooling
 */

import { Module, Global } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';

export const DATABASE_TOKEN = Symbol('DATABASE');

@Global()
@Module({
  providers: [
    {
      provide: DATABASE_TOKEN,
      inject: [ConfigService],
      useFactory: (config: ConfigService) => {
        const dbConfig = config.get('database');
        
        const client = postgres(dbConfig.url, {
          max: dbConfig.poolMax,
          idle_timeout: dbConfig.idleTimeoutMs / 1000,
          connect_timeout: dbConfig.connectionTimeoutMs / 1000,
          ssl: dbConfig.ssl ? 'require' : false,
          transform: postgres.camel,
          // Prepared statements for better performance
          prepare: true,
          // Connection lifecycle hooks
          onnotice: () => {}, // suppress notices in production
        });

        return drizzle(client, {
          schema,
          logger: process.env['NODE_ENV'] === 'development',
        });
      },
    },
  ],
  exports: [DATABASE_TOKEN],
})
export class DatabaseModule {}
