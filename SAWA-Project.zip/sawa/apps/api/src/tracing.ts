/**
 * OpenTelemetry Tracing — MUST be imported before anything else
 * Instruments: HTTP, DB queries, Redis, Bull queues, external calls
 */

import { NodeSDK } from '@opentelemetry/sdk-node';
import { getNodeAutoInstrumentations } from '@opentelemetry/auto-instrumentations-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-http';
import { Resource } from '@opentelemetry/resources';
import { SEMRESATTRS_SERVICE_NAME, SEMRESATTRS_SERVICE_VERSION } from '@opentelemetry/semantic-conventions';

const isEnabled = process.env['OTEL_EXPORTER_OTLP_ENDPOINT'] !== undefined;

if (isEnabled) {
  const sdk = new NodeSDK({
    resource: new Resource({
      [SEMRESATTRS_SERVICE_NAME]: 'sawa-api',
      [SEMRESATTRS_SERVICE_VERSION]: process.env['APP_VERSION'] ?? '1.0.0',
      environment: process.env['NODE_ENV'] ?? 'development',
    }),
    traceExporter: new OTLPTraceExporter({
      url: process.env['OTEL_EXPORTER_OTLP_ENDPOINT'],
    }),
    instrumentations: [
      getNodeAutoInstrumentations({
        '@opentelemetry/instrumentation-fs': { enabled: false },
        '@opentelemetry/instrumentation-dns': { enabled: false },
      }),
    ],
  });

  sdk.start();

  process.on('SIGTERM', () => {
    sdk.shutdown().catch(console.error);
  });
}
