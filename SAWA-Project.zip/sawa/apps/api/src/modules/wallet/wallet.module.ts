/**
 * SAWA — Wallet Module + Service + Controller
 */

import { Module, Injectable, Controller, Get, Post, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus, Inject } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { eq, and, desc, lt, sql } from 'drizzle-orm';
import { IsString, IsOptional, IsIn, Length, IsNumber, Min } from 'class-validator';
import { Type } from 'class-transformer';
import { randomUUID } from 'crypto';
import { Decimal } from 'decimal.js';
import { DATABASE_TOKEN } from '../../database/database.module';
import * as schema from '../../database/schema';
import { LedgerService } from '../ledger/ledger.service';
import { QUEUES } from '../queues/queue.module';
import { JwtAuthGuard, CurrentUser, IdempotencyKey } from '../../common/guards/auth.guard';
import { BullModule } from '@nestjs/bullmq';

// ── DTOs ─────────────────────────────────────────────────────

class TransferDto {
  @IsString()
  receiverIdentifier!: string; // phone, SAWA ID, or username

  @IsString()
  identifierType!: 'phone' | 'sawaId' | 'username' | 'qr';

  @IsString()
  amountSp!: string;

  @IsOptional()
  @IsString()
  @Length(0, 200)
  note?: string;
}

class TransactionsQueryDto {
  @IsOptional()
  @IsString()
  cursor?: string;

  @IsOptional()
  @IsString()
  type?: string;
}

class CurrencyToggleDto {
  @IsIn(['SP', 'SYP', 'USD', 'EUR'])
  currency!: string;
}

// ── Service ──────────────────────────────────────────────────

@Injectable()
export class WalletService {
  constructor(
    @Inject(DATABASE_TOKEN)
    private readonly db: ReturnType<typeof import('drizzle-orm/postgres-js').drizzle>,
    @InjectRedis() private readonly redis: Redis,
    private readonly ledger: LedgerService,
    @InjectQueue(QUEUES.NOTIFICATIONS) private readonly notifQueue: Queue,
  ) {}

  async getWallet(userId: string) {
    const wallet = await this.db.query.wallets.findFirst({
      where: eq(schema.wallets.userId, userId),
    });

    if (!wallet) throw new Error('Wallet not found');

    const rates = await this.getExchangeRates();

    return {
      availableBalance: wallet.availableBalance,
      frozenBalance: wallet.frozenBalance,
      pendingBalance: wallet.pendingBalance,
      cardType: wallet.cardType,
      cardColor: wallet.cardColor,
      preferredCurrency: wallet.preferredCurrency,
      isFrozen: wallet.isFrozen,
      isPremium: wallet.isPremium,
      premiumExpiresAt: wallet.premiumExpiresAt,
      equivalents: {
        syp: new Decimal(wallet.availableBalance).mul(rates.spToSyp).toString(),
        usd: new Decimal(wallet.availableBalance).mul(rates.spToUsd).toString(),
        eur: new Decimal(wallet.availableBalance).mul(rates.spToEur).toString(),
      },
      rates,
      totalTransactionsCount: wallet.totalTransactionsCount,
    };
  }

  async transfer(
    senderId: string,
    dto: TransferDto,
    idempotencyKey: string,
  ) {
    // Resolve receiver
    const receiver = await this.resolveReceiver(dto.receiverIdentifier, dto.identifierType);

    if (receiver.id === senderId) {
      throw new Error('SELF_TRANSFER_NOT_ALLOWED');
    }

    // Check if blocked
    const isBlocked = await this.db.query.blocks.findFirst({
      where: and(
        eq(schema.blocks.blockerId, receiver.id),
        eq(schema.blocks.blockedId, senderId),
      ),
    });

    if (isBlocked) {
      // Don't reveal the block — generic error
      throw new Error('RECEIVER_NOT_FOUND');
    }

    const result = await this.ledger.executeTransfer({
      senderId,
      receiverId: receiver.id,
      amountSp: dto.amountSp,
      idempotencyKey,
      type: 'transfer',
      note: dto.note,
    });

    if (!result.fromCache) {
      // Queue notifications for both parties
      await this.notifQueue.add('transfer-received', {
        receiverId: receiver.id,
        senderId,
        amountSp: result.netAmountSp,
        transactionId: result.transactionId,
      });
    }

    return { ...result, receiver: { id: receiver.id, fullName: receiver.fullName, sawaId: receiver.sawaId } };
  }

  async cancelTransfer(transactionId: string, userId: string): Promise<void> {
    await this.ledger.cancelTransfer(transactionId, userId);

    // Notify both parties
    const tx = await this.db.query.transactions.findFirst({
      where: eq(schema.transactions.id, transactionId),
      columns: { senderId: true, receiverId: true, amountSp: true },
    });

    if (tx?.receiverId) {
      await this.notifQueue.add('transfer-cancelled', {
        senderId: tx.senderId,
        receiverId: tx.receiverId,
        amountSp: tx.amountSp,
        transactionId,
      });
    }
  }

  async getTransactions(userId: string, query: TransactionsQueryDto) {
    const PAGE_SIZE = 30;
    const conditions = [
      sql`(${schema.transactions.senderId} = ${userId} OR ${schema.transactions.receiverId} = ${userId})`,
    ];

    if (query.cursor) {
      conditions.push(lt(schema.transactions.createdAt, new Date(query.cursor)));
    }

    if (query.type) {
      conditions.push(eq(schema.transactions.type, query.type as typeof schema.txTypeEnum.enumValues[number]));
    }

    const txs = await this.db.query.transactions.findMany({
      where: and(...conditions),
      orderBy: [desc(schema.transactions.createdAt)],
      limit: PAGE_SIZE + 1,
    });

    const hasMore = txs.length > PAGE_SIZE;
    const items = hasMore ? txs.slice(0, PAGE_SIZE) : txs;
    const nextCursor = hasMore ? items[items.length - 1]?.createdAt.toISOString() : null;

    return { items, hasMore, nextCursor };
  }

  async resolveReceiver(identifier: string, type: string) {
    let user;

    switch (type) {
      case 'phone':
        user = await this.db.query.users.findFirst({
          where: eq(schema.users.phone, identifier),
          columns: { id: true, fullName: true, sawaId: true, trustScore: true, avatarUrl: true, isFrozen: true, isDeleted: true },
        });
        break;
      case 'sawaId':
        user = await this.db.query.users.findFirst({
          where: eq(schema.users.sawaId, identifier),
          columns: { id: true, fullName: true, sawaId: true, trustScore: true, avatarUrl: true, isFrozen: true, isDeleted: true },
        });
        break;
      case 'username':
        user = await this.db.query.users.findFirst({
          where: eq(schema.users.username, identifier),
          columns: { id: true, fullName: true, sawaId: true, trustScore: true, avatarUrl: true, isFrozen: true, isDeleted: true },
        });
        break;
      default:
        throw new Error('INVALID_IDENTIFIER_TYPE');
    }

    if (!user || user.isDeleted) throw new Error('RECEIVER_NOT_FOUND');
    if (user.isFrozen) throw new Error('RECEIVER_FROZEN');
    return user;
  }

  async lookupReceiver(identifier: string, type: string) {
    return this.resolveReceiver(identifier, type);
  }

  async updatePreferredCurrency(userId: string, currency: string): Promise<void> {
    await this.db
      .update(schema.wallets)
      .set({ preferredCurrency: currency as typeof schema.currencyEnum.enumValues[number] })
      .where(eq(schema.wallets.userId, userId));
  }

  private async getExchangeRates() {
    const cached = await this.redis.get('exchange_rates');
    if (cached) return JSON.parse(cached) as { spToSyp: string; spToUsd: string; spToEur: string };

    const rates = await this.db.query.exchangeRates.findFirst({
      orderBy: [desc(schema.exchangeRates.updatedAt)],
    });

    const result = {
      spToSyp: rates?.spToSyp ?? '100',
      spToUsd: rates?.spToUsd ?? '0.03',
      spToEur: rates?.spToEur ?? '0.028',
    };

    await this.redis.setex('exchange_rates', 300, JSON.stringify(result));
    return result;
  }
}

// ── Controller ────────────────────────────────────────────────

@ApiTags('wallet')
@ApiBearerAuth('JWT')
@UseGuards(JwtAuthGuard)
@Controller({ path: 'wallet', version: '1' })
export class WalletController {
  constructor(private readonly walletService: WalletService) {}

  @Get()
  @ApiOperation({ summary: 'Get wallet balance and card info' })
  async getWallet(@CurrentUser('id') userId: string) {
    const data = await this.walletService.getWallet(userId);
    return { success: true, data };
  }

  @Post('transfer')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'P2P transfer with idempotency' })
  async transfer(
    @CurrentUser('id') userId: string,
    @Body() dto: TransferDto,
    @IdempotencyKey() idempotencyKey: string | undefined,
  ) {
    if (!idempotencyKey) {
      return { success: false, error: { code: 'MISSING_IDEMPOTENCY_KEY', message: 'X-Idempotency-Key header is required' } };
    }
    const data = await this.walletService.transfer(userId, dto, idempotencyKey);
    return { success: true, data };
  }

  @Post('transfer/:id/cancel')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Cancel transfer within 30-second window' })
  async cancelTransfer(
    @Param('id') transactionId: string,
    @CurrentUser('id') userId: string,
  ) {
    await this.walletService.cancelTransfer(transactionId, userId);
    return { success: true, data: { message: 'تم إلغاء التحويل بنجاح' } };
  }

  @Get('transactions')
  @ApiOperation({ summary: 'Get transaction history (cursor-based pagination)' })
  async getTransactions(
    @CurrentUser('id') userId: string,
    @Query() query: TransactionsQueryDto,
  ) {
    const data = await this.walletService.getTransactions(userId, query);
    return { success: true, data };
  }

  @Get('lookup')
  @ApiOperation({ summary: 'Look up receiver before transfer' })
  async lookupReceiver(
    @Query('identifier') identifier: string,
    @Query('type') type: string,
  ) {
    const data = await this.walletService.lookupReceiver(identifier, type);
    return { success: true, data };
  }

  @Post('currency')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update preferred display currency' })
  async updateCurrency(
    @CurrentUser('id') userId: string,
    @Body() dto: CurrencyToggleDto,
  ) {
    await this.walletService.updatePreferredCurrency(userId, dto.currency);
    return { success: true, data: { preferredCurrency: dto.currency } };
  }
}

// ── Module ────────────────────────────────────────────────────

@Module({
  imports: [BullModule.registerQueue({ name: QUEUES.NOTIFICATIONS })],
  controllers: [WalletController],
  providers: [WalletService],
  exports: [WalletService],
})
export class WalletModule {}
