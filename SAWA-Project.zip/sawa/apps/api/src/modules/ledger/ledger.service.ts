/**
 * SAWA — Ledger Service
 * Double-entry bookkeeping — the financial core
 *
 * RULES:
 * 1. Every money movement = 2+ immutable ledger entries
 * 2. sum(debits) === sum(credits) always
 * 3. Ledger entries are NEVER updated or deleted
 * 4. All operations are atomic DB transactions
 * 5. Idempotency key checked before every operation
 */

import {
  Injectable,
  Logger,
  Inject,
  ConflictException,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { eq, and, sql, gt } from 'drizzle-orm';
import { randomUUID } from 'crypto';
import { createHash } from 'crypto';
import { DATABASE_TOKEN } from '../../database/database.module';
import * as schema from '../../database/schema';
import { Decimal } from 'decimal.js';

// Configure Decimal for financial precision
Decimal.set({ precision: 20, rounding: Decimal.ROUND_HALF_UP });

export interface TransferParams {
  senderId: string;
  receiverId: string;
  amountSp: string;
  idempotencyKey: string;
  type?: typeof schema.txTypeEnum.enumValues[number];
  note?: string;
  referenceId?: string;
  referenceType?: string;
  feeOverridePercent?: string;
}

export interface TransferResult {
  transactionId: string;
  amountSp: string;
  feeSp: string;
  netAmountSp: string;
  status: string;
  cancelableUntil?: string;
  fromCache?: boolean;
}

export interface EscrowHoldParams {
  buyerId: string;
  sellerId: string;
  escrowId: string;
  amountSp: string;
  feeSp: string;
  idempotencyKey: string;
}

export interface EscrowReleaseParams {
  escrowId: string;
  buyerId: string;
  sellerId: string;
  amountSp: string;
  feeSp: string;
  idempotencyKey: string;
  isAutoRelease?: boolean;
}

@Injectable()
export class LedgerService {
  private readonly logger = new Logger(LedgerService.name);

  // System account IDs — loaded once at startup
  private systemAccountIds: {
    fees: string;
    escrow: string;
    reserve: string;
  } | null = null;

  constructor(
    @Inject(DATABASE_TOKEN)
    private readonly db: ReturnType<typeof import('drizzle-orm/postgres-js').drizzle>,
    @InjectRedis() private readonly redis: Redis,
  ) {}

  // ── Transfer (P2P) ───────────────────────────────────────────

  async executeTransfer(params: TransferParams): Promise<TransferResult> {
    const {
      senderId,
      receiverId,
      amountSp,
      idempotencyKey,
      type = 'transfer',
      note,
      referenceId,
      referenceType,
    } = params;

    // ── Step 1: Idempotency check ───────────────────────────────
    const cached = await this.getCachedIdempotency(idempotencyKey);
    if (cached) {
      return { ...cached, fromCache: true };
    }

    // ── Step 2: Validate amount ─────────────────────────────────
    const amount = new Decimal(amountSp);
    if (amount.lte(0)) {
      throw new BadRequestException({ code: 'INVALID_AMOUNT', message: 'المبلغ يجب أن يكون أكبر من صفر' });
    }

    // ── Step 3: Get fee from app_config (cached in Redis) ────────
    const feePercent = await this.getFeePercent('p2p');
    const fee = amount.mul(feePercent).div(100).toDecimalPlaces(4);
    const netAmount = amount.minus(fee).toDecimalPlaces(4);

    if (netAmount.lte(0)) {
      throw new BadRequestException({ code: 'INVALID_AMOUNT', message: 'المبلغ أقل من الحد الأدنى بعد الرسوم' });
    }

    const systemAccounts = await this.getSystemAccounts();

    // ── Step 4: Atomic DB transaction ───────────────────────────
    let result: TransferResult;

    try {
      result = await this.db.transaction(async (tx) => {
        // Lock sender wallet row (prevents race conditions)
        const [senderWallet] = await tx.execute(
          sql`SELECT id, available_balance, is_frozen, daily_limit_sp
              FROM wallets
              WHERE user_id = ${senderId}
              FOR UPDATE NOWAIT`,
        ) as Array<{ id: string; available_balance: string; is_frozen: boolean; daily_limit_sp: string }>;

        if (!senderWallet) {
          throw new BadRequestException({ code: 'WALLET_NOT_FOUND', message: 'المحفظة غير موجودة' });
        }

        if (senderWallet.is_frozen) {
          throw new BadRequestException({ code: 'WALLET_FROZEN', message: 'محفظتك مجمدة' });
        }

        // Check sufficient balance (DB constraint also protects, but check early)
        const available = new Decimal(senderWallet.available_balance);
        if (available.lt(amount)) {
          throw new BadRequestException({
            code: 'INSUFFICIENT_BALANCE',
            message: `رصيدك المتاح ${available.toString()} SP — تحاول إرسال ${amount.toString()} SP`,
          });
        }

        // Check daily limit
        const dailyUsed = await this.getDailyTransferUsed(senderId);
        const dailyLimit = new Decimal(senderWallet.daily_limit_sp);
        if (dailyUsed.plus(amount).gt(dailyLimit)) {
          throw new BadRequestException({
            code: 'DAILY_LIMIT_EXCEEDED',
            message: `تجاوزت حد التحويل اليومي (${dailyLimit.toString()} SP)`,
          });
        }

        // Lock receiver wallet
        const [receiverWallet] = await tx.execute(
          sql`SELECT id, is_frozen FROM wallets WHERE user_id = ${receiverId} FOR UPDATE`,
        ) as Array<{ id: string; is_frozen: boolean }>;

        if (!receiverWallet) {
          throw new BadRequestException({ code: 'RECEIVER_NOT_FOUND', message: 'حساب المستقبل غير موجود' });
        }

        if (receiverWallet.is_frozen) {
          throw new BadRequestException({ code: 'RECEIVER_FROZEN', message: 'حساب المستقبل مجمد' });
        }

        // Get ledger accounts
        const senderAccount = await this.getUserLedgerAccount(tx, senderId, 'asset');
        const receiverAccount = await this.getUserLedgerAccount(tx, receiverId, 'asset');
        const feeAccount = systemAccounts.fees;

        // Create transaction record
        const txId = randomUUID();
        const cancelableUntil = new Date(Date.now() + 30 * 1000);

        await tx.insert(schema.transactions).values({
          id: txId,
          senderId,
          receiverId,
          amountSp: amount.toString(),
          feeSp: fee.toString(),
          netAmountSp: netAmount.toString(),
          type,
          status: 'completed',
          idempotencyKey,
          note: note ?? null,
          referenceId: referenceId ?? null,
          referenceType: referenceType ?? null,
          cancelableUntil,
        });

        // Double-entry ledger entries
        await tx.insert(schema.ledgerEntries).values([
          {
            id: randomUUID(),
            transactionId: txId,
            debitAccountId: senderAccount.id,
            creditAccountId: systemAccounts.reserve,
            amount: amount.toString(),
            currency: 'SP',
            type: 'debit',
            memo: `Transfer to ${receiverId}`,
          },
          {
            id: randomUUID(),
            transactionId: txId,
            debitAccountId: systemAccounts.reserve,
            creditAccountId: receiverAccount.id,
            amount: netAmount.toString(),
            currency: 'SP',
            type: 'credit',
            memo: `Received from ${senderId}`,
          },
          {
            id: randomUUID(),
            transactionId: txId,
            debitAccountId: systemAccounts.reserve,
            creditAccountId: feeAccount,
            amount: fee.toString(),
            currency: 'SP',
            type: 'fee',
            memo: `P2P fee`,
          },
        ]);

        // Update balances atomically
        await tx.execute(
          sql`UPDATE wallets
              SET available_balance = available_balance - ${amount.toString()}::numeric,
                  updated_at = NOW()
              WHERE user_id = ${senderId}
              AND available_balance >= ${amount.toString()}::numeric`,
        );

        await tx.execute(
          sql`UPDATE wallets
              SET available_balance = available_balance + ${netAmount.toString()}::numeric,
                  updated_at = NOW()
              WHERE user_id = ${receiverId}`,
        );

        // Increment transaction count
        await tx.execute(
          sql`UPDATE wallets SET total_transactions_count = total_transactions_count + 1
              WHERE user_id = ${senderId} OR user_id = ${receiverId}`,
        );

        // Save idempotency response
        const response: TransferResult = {
          transactionId: txId,
          amountSp: amount.toString(),
          feeSp: fee.toString(),
          netAmountSp: netAmount.toString(),
          status: 'completed',
          cancelableUntil: cancelableUntil.toISOString(),
        };

        await tx.insert(schema.idempotencyKeys).values({
          id: randomUUID(),
          key: idempotencyKey,
          userId: senderId,
          endpoint: '/api/v1/wallet/transfer',
          response,
          statusCode: 200,
          expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
        });

        return response;
      });
    } catch (err: unknown) {
      if ((err as { code?: string }).code === '55P03') {
        // Lock not available — concurrent request
        throw new ConflictException({
          code: 'CONCURRENT_OPERATION',
          message: 'عملية أخرى قيد التنفيذ. حاول مجدداً.',
        });
      }
      throw err;
    }

    // Store cancel token in Redis (30 seconds)
    await this.redis.setex(
      `cancel:${result.transactionId}`,
      30,
      JSON.stringify({ senderId, receiverId, amountSp: amount.toString(), netAmountSp: netAmount.toString(), feeSp: fee.toString() }),
    );

    // Update daily usage
    await this.incrementDailyTransfer(senderId, amount.toString());

    this.logger.log(`Transfer completed: ${senderId} → ${receiverId} | ${amount} SP`);
    return result;
  }

  // ── Transfer Cancellation (30s window) ───────────────────────

  async cancelTransfer(transactionId: string, userId: string): Promise<void> {
    const cancelData = await this.redis.get(`cancel:${transactionId}`);
    if (!cancelData) {
      throw new BadRequestException({
        code: 'CANCELLATION_WINDOW_EXPIRED',
        message: 'انتهت مهلة إلغاء التحويل (30 ثانية)',
      });
    }

    const { senderId, receiverId, amountSp, netAmountSp, feeSp } =
      JSON.parse(cancelData) as { senderId: string; receiverId: string; amountSp: string; netAmountSp: string; feeSp: string };

    if (senderId !== userId) {
      throw new BadRequestException({ code: 'UNAUTHORIZED_CANCEL' });
    }

    await this.db.transaction(async (tx) => {
      // Reverse: refund sender, deduct from receiver
      await tx.execute(
        sql`UPDATE wallets SET available_balance = available_balance + ${amountSp}::numeric WHERE user_id = ${senderId}`,
      );
      await tx.execute(
        sql`UPDATE wallets SET available_balance = available_balance - ${netAmountSp}::numeric
            WHERE user_id = ${receiverId} AND available_balance >= ${netAmountSp}::numeric`,
      );

      // Mark transaction as cancelled
      await tx
        .update(schema.transactions)
        .set({ status: 'cancelled', canceledAt: new Date(), canceledBy: userId })
        .where(eq(schema.transactions.id, transactionId));

      // Create reversal ledger entries
      const senderAccount = await this.getUserLedgerAccount(tx, senderId, 'asset');
      const receiverAccount = await this.getUserLedgerAccount(tx, receiverId, 'asset');
      const systemAccounts = await this.getSystemAccounts();

      const reversalTxId = randomUUID();
      await tx.insert(schema.transactions).values({
        id: reversalTxId,
        senderId: receiverId,
        receiverId: senderId,
        amountSp: netAmountSp,
        feeSp: '0.0000',
        netAmountSp: netAmountSp,
        type: 'reversal',
        status: 'completed',
        idempotencyKey: randomUUID(),
        referenceId: transactionId,
        referenceType: 'transfer_reversal',
      });

      await tx.insert(schema.ledgerEntries).values([
        {
          id: randomUUID(),
          transactionId: reversalTxId,
          debitAccountId: receiverAccount.id,
          creditAccountId: senderAccount.id,
          amount: netAmountSp,
          currency: 'SP',
          type: 'reversal',
          memo: `Reversal of transfer ${transactionId}`,
        },
        {
          id: randomUUID(),
          transactionId: reversalTxId,
          debitAccountId: systemAccounts.fees,
          creditAccountId: senderAccount.id,
          amount: feeSp,
          currency: 'SP',
          type: 'refund',
          memo: `Fee refund for reversal ${transactionId}`,
        },
      ]);
    });

    await this.redis.del(`cancel:${transactionId}`);
    this.logger.log(`Transfer cancelled: ${transactionId}`);
  }

  // ── Escrow Hold ──────────────────────────────────────────────

  async holdForEscrow(params: EscrowHoldParams): Promise<string> {
    const { buyerId, sellerId, escrowId, amountSp, feeSp, idempotencyKey } = params;

    const cached = await this.getCachedIdempotency(idempotencyKey);
    if (cached) return cached['transactionId'] as string;

    const amount = new Decimal(amountSp);
    const fee = new Decimal(feeSp);
    const systemAccounts = await this.getSystemAccounts();

    const txId = await this.db.transaction(async (tx) => {
      // Lock buyer wallet
      const [wallet] = await tx.execute(
        sql`SELECT id, available_balance, is_frozen FROM wallets WHERE user_id = ${buyerId} FOR UPDATE NOWAIT`,
      ) as Array<{ id: string; available_balance: string; is_frozen: boolean }>;

      if (!wallet || wallet.is_frozen) {
        throw new BadRequestException({ code: 'WALLET_UNAVAILABLE' });
      }

      const available = new Decimal(wallet.available_balance);
      if (available.lt(amount)) {
        throw new BadRequestException({ code: 'INSUFFICIENT_BALANCE' });
      }

      const transactionId = randomUUID();
      await tx.insert(schema.transactions).values({
        id: transactionId,
        senderId: buyerId,
        receiverId: sellerId,
        amountSp: amount.toString(),
        feeSp: fee.toString(),
        netAmountSp: amount.minus(fee).toString(),
        type: 'escrow_hold',
        status: 'completed',
        idempotencyKey,
        referenceId: escrowId,
        referenceType: 'escrow',
      });

      // Move from available to frozen
      await tx.execute(
        sql`UPDATE wallets
            SET available_balance = available_balance - ${amount.toString()}::numeric,
                frozen_balance = frozen_balance + ${amount.toString()}::numeric
            WHERE user_id = ${buyerId} AND available_balance >= ${amount.toString()}::numeric`,
      );

      // Create frozen_balance record
      await tx.insert(schema.frozenBalances).values({
        id: randomUUID(),
        userId: buyerId,
        amount: amount.toString(),
        reason: 'escrow',
        referenceId: escrowId,
        referenceType: 'escrow',
        holdTransactionId: transactionId,
      });

      // Ledger: buyer asset → escrow account
      const buyerAccount = await this.getUserLedgerAccount(tx, buyerId, 'asset');
      await tx.insert(schema.ledgerEntries).values({
        id: randomUUID(),
        transactionId,
        debitAccountId: buyerAccount.id,
        creditAccountId: systemAccounts.escrow,
        amount: amount.toString(),
        currency: 'SP',
        type: 'hold',
        memo: `Escrow hold for ${escrowId}`,
      });

      await tx.insert(schema.idempotencyKeys).values({
        id: randomUUID(),
        key: idempotencyKey,
        userId: buyerId,
        endpoint: '/api/v1/escrow',
        response: { transactionId },
        statusCode: 201,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      });

      return transactionId;
    });

    return txId;
  }

  // ── Escrow Release ───────────────────────────────────────────

  async releaseEscrow(params: EscrowReleaseParams): Promise<string> {
    const { escrowId, buyerId, sellerId, amountSp, feeSp, idempotencyKey } = params;

    const cached = await this.getCachedIdempotency(idempotencyKey);
    if (cached) return cached['transactionId'] as string;

    const amount = new Decimal(amountSp);
    const fee = new Decimal(feeSp);
    const netAmount = amount.minus(fee);
    const systemAccounts = await this.getSystemAccounts();

    const txId = await this.db.transaction(async (tx) => {
      const transactionId = randomUUID();

      await tx.insert(schema.transactions).values({
        id: transactionId,
        senderId: buyerId,
        receiverId: sellerId,
        amountSp: amount.toString(),
        feeSp: fee.toString(),
        netAmountSp: netAmount.toString(),
        type: 'escrow_release',
        status: 'completed',
        idempotencyKey,
        referenceId: escrowId,
        referenceType: 'escrow',
      });

      // Release frozen from buyer
      await tx.execute(
        sql`UPDATE wallets
            SET frozen_balance = frozen_balance - ${amount.toString()}::numeric
            WHERE user_id = ${buyerId} AND frozen_balance >= ${amount.toString()}::numeric`,
      );

      // Credit net to seller
      await tx.execute(
        sql`UPDATE wallets
            SET available_balance = available_balance + ${netAmount.toString()}::numeric
            WHERE user_id = ${sellerId}`,
      );

      // Release frozen_balance record
      await tx.execute(
        sql`UPDATE frozen_balances
            SET is_released = true, released_at = NOW(), release_transaction_id = ${transactionId}
            WHERE reference_id = ${escrowId} AND is_released = false`,
      );

      const buyerAccount = await this.getUserLedgerAccount(tx, buyerId, 'asset');
      const sellerAccount = await this.getUserLedgerAccount(tx, sellerId, 'asset');

      await tx.insert(schema.ledgerEntries).values([
        {
          id: randomUUID(),
          transactionId,
          debitAccountId: systemAccounts.escrow,
          creditAccountId: sellerAccount.id,
          amount: netAmount.toString(),
          currency: 'SP',
          type: 'release',
          memo: `Escrow release for ${escrowId}`,
        },
        {
          id: randomUUID(),
          transactionId,
          debitAccountId: systemAccounts.escrow,
          creditAccountId: systemAccounts.fees,
          amount: fee.toString(),
          currency: 'SP',
          type: 'fee',
          memo: `Escrow fee for ${escrowId}`,
        },
      ]);

      await tx.insert(schema.idempotencyKeys).values({
        id: randomUUID(),
        key: idempotencyKey,
        userId: sellerId,
        endpoint: `/api/v1/escrow/${escrowId}/release`,
        response: { transactionId },
        statusCode: 200,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      });

      return transactionId;
    });

    return txId;
  }

  // ── Reconciliation ───────────────────────────────────────────

  async runReconciliation(): Promise<{ discrepancies: number; details: unknown[] }> {
    const discrepancies: Array<{
      userId: string;
      walletBalance: string;
      ledgerBalance: string;
      difference: string;
    }> = [];

    // Get all user wallets
    const wallets = await this.db.query.wallets.findMany({
      columns: { userId: true, availableBalance: true, frozenBalance: true },
    });

    for (const wallet of wallets) {
      // Get ledger balance from entries
      const [ledgerResult] = await this.db.execute(
        sql`SELECT
              COALESCE(SUM(CASE WHEN credit_account_id = la.id THEN le.amount::numeric ELSE 0 END), 0) -
              COALESCE(SUM(CASE WHEN debit_account_id = la.id THEN le.amount::numeric ELSE 0 END), 0) as ledger_balance
            FROM ledger_accounts la
            LEFT JOIN ledger_entries le ON la.id = le.debit_account_id OR la.id = le.credit_account_id
            WHERE la.user_id = ${wallet.userId} AND la.type = 'asset'`,
      ) as Array<{ ledger_balance: string }>;

      const walletTotal = new Decimal(wallet.availableBalance)
        .plus(wallet.frozenBalance);
      const ledgerBalance = new Decimal(ledgerResult?.ledger_balance ?? '0');

      if (!walletTotal.eq(ledgerBalance)) {
        discrepancies.push({
          userId: wallet.userId,
          walletBalance: walletTotal.toString(),
          ledgerBalance: ledgerBalance.toString(),
          difference: walletTotal.minus(ledgerBalance).toString(),
        });
        this.logger.error(`Reconciliation discrepancy: user ${wallet.userId}`);
      }
    }

    return { discrepancies: discrepancies.length, details: discrepancies };
  }

  // ── Private Helpers ──────────────────────────────────────────

  private async getUserLedgerAccount(
    tx: unknown,
    userId: string,
    type: string,
  ): Promise<{ id: string }> {
    const db = (tx as typeof this.db) ?? this.db;
    const existing = await db.query.ledgerAccounts.findFirst({
      where: and(
        eq(schema.ledgerAccounts.userId, userId),
        eq(schema.ledgerAccounts.type, type as typeof schema.accountTypeEnum.enumValues[number]),
      ),
      columns: { id: true },
    });

    if (existing) return existing;

    // Auto-create if not exists
    const [created] = await db
      .insert(schema.ledgerAccounts)
      .values({ id: randomUUID(), userId, type: type as typeof schema.accountTypeEnum.enumValues[number], balance: '0.0000', currency: 'SP' })
      .returning({ id: schema.ledgerAccounts.id });

    return created!;
  }

  private async getSystemAccounts(): Promise<{ fees: string; escrow: string; reserve: string }> {
    if (this.systemAccountIds) return this.systemAccountIds;

    const accounts = await this.db.query.ledgerAccounts.findMany({
      where: eq(schema.ledgerAccounts.isSystem, true),
      columns: { id: true, name: true },
    });

    const map: Record<string, string> = {};
    for (const acc of accounts) {
      if (acc.name) map[acc.name] = acc.id;
    }

    this.systemAccountIds = {
      fees: map['SAWA_FEES'] ?? '',
      escrow: map['SAWA_ESCROW'] ?? '',
      reserve: map['SAWA_RESERVE'] ?? '',
    };

    return this.systemAccountIds;
  }

  private async getCachedIdempotency(key: string): Promise<Record<string, unknown> | null> {
    const existing = await this.db.query.idempotencyKeys.findFirst({
      where: eq(schema.idempotencyKeys.key, key),
      columns: { response: true, expiresAt: true },
    });

    if (!existing) return null;
    if (new Date() > existing.expiresAt) return null;
    return existing.response as Record<string, unknown>;
  }

  private async getFeePercent(type: 'p2p' | 'escrow' | 'market' | 'agent'): Promise<Decimal> {
    const cached = await this.redis.get(`config:fee:${type}`);
    if (cached) return new Decimal(cached);

    const config = await this.db.query.appConfig.findFirst({
      columns: {
        p2pFeePercent: true,
        escrowFeePercent: true,
        marketFeePercent: true,
        agentFeePercent: true,
      },
    });

    const percentMap: Record<string, string> = {
      p2p: config?.p2pFeePercent ?? '1.5',
      escrow: config?.escrowFeePercent ?? '2.0',
      market: config?.marketFeePercent ?? '1.0',
      agent: config?.agentFeePercent ?? '1.0',
    };

    const percent = percentMap[type] ?? '1.5';
    await this.redis.setex(`config:fee:${type}`, 300, percent);
    return new Decimal(percent);
  }

  private async getDailyTransferUsed(userId: string): Promise<Decimal> {
    const key = `daily_transfer:${userId}:${new Date().toISOString().slice(0, 10)}`;
    const used = await this.redis.get(key);
    return new Decimal(used ?? '0');
  }

  private async incrementDailyTransfer(userId: string, amount: string): Promise<void> {
    const key = `daily_transfer:${userId}:${new Date().toISOString().slice(0, 10)}`;
    await this.redis.incrbyfloat(key, parseFloat(amount));
    await this.redis.expireat(key, Math.floor(new Date().setHours(23, 59, 59, 999) / 1000));
  }
}
