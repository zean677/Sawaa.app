/**
 * SAWA — Health Module
 * GET /api/v1/health — checks all services
 */

import { Module, Controller, Get, Inject } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { DATABASE_TOKEN } from '../../database/database.module';
import { sql } from 'drizzle-orm';

interface ServiceHealth {
  status: 'healthy' | 'degraded' | 'unhealthy';
  latencyMs?: number;
  message?: string;
}

interface HealthResponse {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  version: string;
  uptime: number;
  services: {
    database: ServiceHealth;
    redis: ServiceHealth;
    search?: ServiceHealth;
  };
}

@Controller({ path: 'health', version: '1' })
export class HealthController {
  constructor(
    @Inject(DATABASE_TOKEN) private readonly db: ReturnType<typeof import('drizzle-orm/postgres-js').drizzle>,
    @InjectRedis() private readonly redis: Redis,
    private readonly config: ConfigService,
  ) {}

  @Get()
  async check(): Promise<HealthResponse> {
    const [dbHealth, redisHealth] = await Promise.all([
      this.checkDatabase(),
      this.checkRedis(),
    ]);

    const allHealthy = dbHealth.status === 'healthy' && redisHealth.status === 'healthy';
    const anyUnhealthy = dbHealth.status === 'unhealthy' || redisHealth.status === 'unhealthy';

    return {
      status: anyUnhealthy ? 'unhealthy' : allHealthy ? 'healthy' : 'degraded',
      timestamp: new Date().toISOString(),
      version: this.config.get<string>('app.version') ?? '1.0.0',
      uptime: Math.floor(process.uptime()),
      services: {
        database: dbHealth,
        redis: redisHealth,
      },
    };
  }

  @Get('ready')
  async ready(): Promise<{ ready: boolean }> {
    try {
      await this.db.execute(sql`SELECT 1`);
      await this.redis.ping();
      return { ready: true };
    } catch {
      return { ready: false };
    }
  }

  @Get('live')
  live(): { alive: boolean; uptime: number } {
    return { alive: true, uptime: Math.floor(process.uptime()) };
  }

  private async checkDatabase(): Promise<ServiceHealth> {
    const start = Date.now();
    try {
      await this.db.execute(sql`SELECT 1`);
      return { status: 'healthy', latencyMs: Date.now() - start };
    } catch (err) {
      return {
        status: 'unhealthy',
        latencyMs: Date.now() - start,
        message: 'Database connection failed',
      };
    }
  }

  private async checkRedis(): Promise<ServiceHealth> {
    const start = Date.now();
    try {
      await this.redis.ping();
      return { status: 'healthy', latencyMs: Date.now() - start };
    } catch {
      return {
        status: 'unhealthy',
        latencyMs: Date.now() - start,
        message: 'Redis connection failed',
      };
    }
  }
}

@Module({
  controllers: [HealthController],
})
export class HealthModule {}
