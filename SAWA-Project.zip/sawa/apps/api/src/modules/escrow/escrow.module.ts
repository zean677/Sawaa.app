import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { EscrowService } from './escrow.service';
import { EscrowController } from './escrow.controller';
import { QUEUES } from '../queues/queue.module';

@Module({
  imports: [BullModule.registerQueue({ name: QUEUES.NOTIFICATIONS }, { name: QUEUES.ESCROW_AUTO_RELEASE })],
  controllers: [EscrowController],
  providers: [EscrowService],
  exports: [EscrowService],
})
export class EscrowModule {}
