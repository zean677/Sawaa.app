import { Controller, Get, Post, Param, Body, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { IsString, IsOptional, IsArray, ValidateNested, IsDateString, ArrayMaxSize } from 'class-validator';
import { Type } from 'class-transformer';
import { EscrowService } from './escrow.service';
import { JwtAuthGuard, CurrentUser } from '../../common/guards/auth.guard';

class MilestoneDto { @IsString() title!: string; @IsString() amountSp!: string; @IsOptional() @IsDateString() deadline?: string; }
class CreateEscrowDto {
  @IsString() sellerId!: string;
  @IsString() amountSp!: string;
  @IsString() description!: string;
  @IsOptional() @IsDateString() deadline?: string;
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => MilestoneDto) @ArrayMaxSize(5) milestones?: MilestoneDto[];
}

@ApiTags('escrow') @ApiBearerAuth('JWT') @UseGuards(JwtAuthGuard)
@Controller({ path: 'escrow', version: '1' })
export class EscrowController {
  constructor(private readonly svc: EscrowService) {}
  @Get() async list(@CurrentUser('id') uid: string, @Query('status') status?: string) { return { success: true, data: await this.svc.getUserEscrows(uid, status) }; }
  @Get(':id') async getOne(@Param('id') id: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.getById(id, uid) }; }
  @Post() @HttpCode(HttpStatus.CREATED) async create(@CurrentUser('id') uid: string, @Body() dto: CreateEscrowDto) { return { success: true, data: await this.svc.create(uid, { ...dto, deadline: dto.deadline ? new Date(dto.deadline) : undefined }) }; }
  @Post(':id/deliver') @HttpCode(HttpStatus.OK) async deliver(@Param('id') id: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.confirmDelivery(id, uid) }; }
  @Post(':id/confirm') @HttpCode(HttpStatus.OK) async confirm(@Param('id') id: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.confirmReceipt(id, uid) }; }
  @Post(':id/milestone/:mid/confirm') @HttpCode(HttpStatus.OK) async milestone(@Param('id') id: string, @Param('mid') mid: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.confirmMilestone(id, uid, mid) }; }
  @Post(':id/dispute') @HttpCode(HttpStatus.OK) async dispute(@Param('id') id: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.openDispute(id, uid) }; }
  @Post(':id/cancel') @HttpCode(HttpStatus.OK) async cancel(@Param('id') id: string, @CurrentUser('id') uid: string) { return { success: true, data: await this.svc.requestCancellation(id, uid) }; }
}
