/**
 * SAWA — Escrow Service
 * Atomic escrow lifecycle management
 */

import { Injectable, BadRequestException, ForbiddenException, Inject, Logger } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { eq, and, lte, or } from 'drizzle-orm';
import { randomUUID } from 'crypto';
import { Decimal } from 'decimal.js';
import { DATABASE_TOKEN } from '../../database/database.module';
import * as schema from '../../database/schema';
import { LedgerService } from '../ledger/ledger.service';
import { QUEUES } from '../queues/queue.module';

@Injectable()
export class EscrowService {
  private readonly logger = new Logger(EscrowService.name);

  constructor(
    @Inject(DATABASE_TOKEN) private readonly db: ReturnType<typeof import('drizzle-orm/postgres-js').drizzle>,
    private readonly ledger: LedgerService,
    @InjectQueue(QUEUES.NOTIFICATIONS) private readonly notifQueue: Queue,
  ) {}

  async create(buyerId: string, dto: {
    sellerId: string;
    amountSp: string;
    description: string;
    deadline?: Date;
    milestones?: Array<{ title: string; amountSp: string; deadline?: string }>;
  }) {
    if (buyerId === dto.sellerId) {
      throw new BadRequestException({ code: 'SELF_ESCROW', message: 'لا يمكنك فتح صفقة مع نفسك' });
    }

    // Validate milestones
    if (dto.milestones && dto.milestones.length > 5) {
      throw new BadRequestException({ code: 'TOO_MANY_MILESTONES', message: 'الحد الأقصى 5 مراحل' });
    }

    if (dto.milestones && dto.milestones.length > 0) {
      const milestonesTotal = dto.milestones.reduce(
        (sum, m) => sum.plus(m.amountSp), new Decimal(0)
      );
      if (!milestonesTotal.eq(dto.amountSp)) {
        throw new BadRequestException({ code: 'MILESTONES_MISMATCH', message: 'مجموع المراحل لا يساوي المبلغ الكلي' });
      }
    }

    // Get fee from config
    const config = await this.db.query.appConfig.findFirst();
    const feePercent = new Decimal(config?.escrowFeePercent ?? '2.0');
    const amount = new Decimal(dto.amountSp);
    const fee = amount.mul(feePercent).div(100).toDecimalPlaces(4);
    const netAmount = amount.minus(fee);

    const escrowId = randomUUID();
    const idempotencyKey = randomUUID();

    // Hold funds from buyer
    const holdTxId = await this.ledger.holdForEscrow({
      buyerId,
      sellerId: dto.sellerId,
      escrowId,
      amountSp: amount.toString(),
      feeSp: fee.toString(),
      idempotencyKey,
    });

    const milestones = dto.milestones?.map((m, i) => ({
      id: randomUUID(),
      title: m.title,
      amountSp: m.amountSp,
      status: 'pending' as const,
      deadline: m.deadline ?? null,
      releasedAt: null,
    }));

    const [newEscrow] = await this.db.insert(schema.escrow).values({
      id: escrowId,
      buyerId,
      sellerId: dto.sellerId,
      amountSp: amount.toString(),
      feeSp: fee.toString(),
      netAmountSp: netAmount.toString(),
      status: 'pending',
      description: dto.description,
      milestones: milestones ?? null,
      deadline: dto.deadline ?? null,
      holdTransactionId: holdTxId,
    }).returning();

    // Create linked chat room
    await this.db.insert(schema.chatRooms).values({
      id: randomUUID(),
      userOneId: buyerId,
      userTwoId: dto.sellerId,
      escrowId,
    }).onConflictDoNothing();

    // Notify seller
    await this.notifQueue.add('escrow-created', {
      escrowId,
      sellerId: dto.sellerId,
      buyerId,
      amountSp: amount.toString(),
    });

    return newEscrow;
  }

  async confirmDelivery(escrowId: string, sellerId: string) {
    const escrow = await this.getAndValidate(escrowId, sellerId, 'seller');
    if (escrow.status !== 'pending') {
      throw new BadRequestException({ code: 'INVALID_STATUS', message: 'لا يمكن تأكيد التسليم في هذه الحالة' });
    }

    const config = await this.db.query.appConfig.findFirst();
    const releaseDays = config?.escrowAutoReleaseDays ?? 7;
    const autoReleaseAt = new Date(Date.now() + releaseDays * 24 * 60 * 60 * 1000);

    await this.db.update(schema.escrow)
      .set({ autoReleaseAt, updatedAt: new Date() })
      .where(eq(schema.escrow.id, escrowId));

    // Notify buyer
    await this.notifQueue.add('escrow-delivery-confirmed', {
      escrowId, buyerId: escrow.buyerId, autoReleaseAt,
    });

    return { autoReleaseAt };
  }

  async confirmReceipt(escrowId: string, buyerId: string) {
    const escrow = await this.getAndValidate(escrowId, buyerId, 'buyer');
    if (escrow.status !== 'pending') {
      throw new BadRequestException({ code: 'INVALID_STATUS' });
    }

    const idempotencyKey = randomUUID();
    const txId = await this.ledger.releaseEscrow({
      escrowId,
      buyerId: escrow.buyerId,
      sellerId: escrow.sellerId,
      amountSp: escrow.amountSp,
      feeSp: escrow.feeSp,
      idempotencyKey,
    });

    await this.db.update(schema.escrow)
      .set({ status: 'completed', releaseTransactionId: txId, updatedAt: new Date() })
      .where(eq(schema.escrow.id, escrowId));

    await this.notifQueue.add('escrow-completed', {
      escrowId, sellerId: escrow.sellerId, amountSp: escrow.netAmountSp,
    });

    return { status: 'completed', transactionId: txId };
  }

  async confirmMilestone(escrowId: string, buyerId: string, milestoneId: string) {
    const escrow = await this.getAndValidate(escrowId, buyerId, 'buyer');
    const milestones = escrow.milestones as Array<{ id: string; amountSp: string; status: string; releasedAt: string | null; title: string; deadline: string | null }> | null;

    if (!milestones) throw new BadRequestException({ code: 'NO_MILESTONES' });

    const milestone = milestones.find(m => m.id === milestoneId);
    if (!milestone) throw new BadRequestException({ code: 'MILESTONE_NOT_FOUND' });
    if (milestone.status === 'completed') throw new BadRequestException({ code: 'MILESTONE_ALREADY_COMPLETED' });

    const idempotencyKey = randomUUID();
    const txId = await this.ledger.releaseEscrow({
      escrowId,
      buyerId: escrow.buyerId,
      sellerId: escrow.sellerId,
      amountSp: milestone.amountSp,
      feeSp: new Decimal(milestone.amountSp).mul('0.02').toDecimalPlaces(4).toString(),
      idempotencyKey,
    });

    const updatedMilestones = milestones.map(m =>
      m.id === milestoneId ? { ...m, status: 'completed', releasedAt: new Date().toISOString() } : m
    );

    const allCompleted = updatedMilestones.every(m => m.status === 'completed');

    await this.db.update(schema.escrow)
      .set({
        milestones: updatedMilestones,
        status: allCompleted ? 'completed' : 'pending',
        updatedAt: new Date(),
      })
      .where(eq(schema.escrow.id, escrowId));

    return { milestoneId, status: 'completed', transactionId: txId };
  }

  async openDispute(escrowId: string, userId: string) {
    const escrow = await this.db.query.escrow.findFirst({ where: eq(schema.escrow.id, escrowId) });
    if (!escrow) throw new BadRequestException({ code: 'ESCROW_NOT_FOUND' });
    if (escrow.buyerId !== userId && escrow.sellerId !== userId) throw new ForbiddenException();
    if (escrow.status !== 'pending') throw new BadRequestException({ code: 'CANNOT_DISPUTE' });

    await this.db.update(schema.escrow)
      .set({
        status: 'disputed',
        disputeOpenedAt: new Date(),
        disputeOpenedBy: userId,
        updatedAt: new Date(),
      })
      .where(eq(schema.escrow.id, escrowId));

    // Lock chat as evidence
    await this.db.update(schema.chatRooms)
      .set({ isEvidence: true })
      .where(eq(schema.chatRooms.escrowId, escrowId));

    await this.notifQueue.add('dispute-opened', { escrowId, openedBy: userId, escrow });
    return { status: 'disputed' };
  }

  async requestCancellation(escrowId: string, userId: string) {
    const escrow = await this.db.query.escrow.findFirst({ where: eq(schema.escrow.id, escrowId) });
    if (!escrow) throw new BadRequestException({ code: 'ESCROW_NOT_FOUND' });
    if (escrow.buyerId !== userId && escrow.sellerId !== userId) throw new ForbiddenException();
    if (escrow.status !== 'pending') throw new BadRequestException({ code: 'CANNOT_CANCEL' });

    // If other party already requested — auto-cancel
    if (escrow.cancellationRequestedBy && escrow.cancellationRequestedBy !== userId) {
      return this.executeCancellation(escrowId, escrow.buyerId, escrow.sellerId, escrow.amountSp, escrow.feeSp);
    }

    await this.db.update(schema.escrow)
      .set({ cancellationRequestedBy: userId, cancellationRequestedAt: new Date(), updatedAt: new Date() })
      .where(eq(schema.escrow.id, escrowId));

    const otherId = userId === escrow.buyerId ? escrow.sellerId : escrow.buyerId;
    await this.notifQueue.add('cancellation-requested', { escrowId, requestedBy: userId, notifyId: otherId });

    return { status: 'cancellation_requested' };
  }

  async processAutoReleases(): Promise<number> {
    const now = new Date();
    const overdueEscrows = await this.db.query.escrow.findMany({
      where: and(eq(schema.escrow.status, 'pending'), lte(schema.escrow.autoReleaseAt, now)),
    });

    let released = 0;
    for (const e of overdueEscrows) {
      try {
        const txId = await this.ledger.releaseEscrow({
          escrowId: e.id,
          buyerId: e.buyerId,
          sellerId: e.sellerId,
          amountSp: e.amountSp,
          feeSp: e.feeSp,
          idempotencyKey: randomUUID(),
          isAutoRelease: true,
        });

        await this.db.update(schema.escrow)
          .set({ status: 'completed', releaseTransactionId: txId, updatedAt: new Date() })
          .where(eq(schema.escrow.id, e.id));

        await this.notifQueue.add('escrow-auto-released', { escrowId: e.id, sellerId: e.sellerId });
        released++;
      } catch (err) {
        this.logger.error(`Auto-release failed for escrow ${e.id}: ${String(err)}`);
      }
    }
    return released;
  }

  async getUserEscrows(userId: string, status?: string) {
    const conditions = [or(eq(schema.escrow.buyerId, userId), eq(schema.escrow.sellerId, userId))];
    if (status) conditions.push(eq(schema.escrow.status, status as typeof schema.escrowStatusEnum.enumValues[number]));

    return this.db.query.escrow.findMany({ where: and(...conditions), orderBy: (e, { desc }) => [desc(e.createdAt)] });
  }

  async getById(escrowId: string, userId: string) {
    const escrow = await this.db.query.escrow.findFirst({ where: eq(schema.escrow.id, escrowId) });
    if (!escrow) throw new BadRequestException({ code: 'ESCROW_NOT_FOUND' });
    if (escrow.buyerId !== userId && escrow.sellerId !== userId) throw new ForbiddenException();
    return escrow;
  }

  private async getAndValidate(escrowId: string, userId: string, role: 'buyer' | 'seller') {
    const escrow = await this.db.query.escrow.findFirst({ where: eq(schema.escrow.id, escrowId) });
    if (!escrow) throw new BadRequestException({ code: 'ESCROW_NOT_FOUND' });
    if (role === 'buyer' && escrow.buyerId !== userId) throw new ForbiddenException({ code: 'NOT_BUYER' });
    if (role === 'seller' && escrow.sellerId !== userId) throw new ForbiddenException({ code: 'NOT_SELLER' });
    return escrow;
  }

  private async executeCancellation(escrowId: string, buyerId: string, sellerId: string, amountSp: string, feeSp: string) {
    const txId = await this.ledger.releaseEscrow({
      escrowId, buyerId, sellerId: buyerId, // refund to buyer
      amountSp, feeSp: '0.0000', idempotencyKey: randomUUID(),
    });

    await this.db.update(schema.escrow)
      .set({ status: 'cancelled', updatedAt: new Date() })
      .where(eq(schema.escrow.id, escrowId));

    return { status: 'cancelled', transactionId: txId };
  }
}
