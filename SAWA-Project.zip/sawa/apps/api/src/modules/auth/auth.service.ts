/**
 * SAWA — Auth Service
 * Handles: OTP verify, Google OAuth, Email/Password, JWT, Sessions
 */

import {
  Injectable,
  UnauthorizedException,
  ConflictException,
  ForbiddenException,
  BadRequestException,
  Logger,
  Inject,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InjectRedis } from '@nestjs-modules/ioredis';
import Redis from 'ioredis';
import { eq, and, lt, count } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';
import { randomUUID } from 'crypto';
import { createHash } from 'crypto';
import { DATABASE_TOKEN } from '../../database/database.module';
import * as schema from '../../database/schema';
import { OtpService } from './otp.service';
import { parsePhoneNumber } from 'libphonenumber-js';

export interface TokenPair {
  accessToken: string;
  refreshToken: string;
  expiresAt: string;
}

export interface JwtPayload {
  sub: string;     // userId
  role: string;
  sessionId: string;
  iat?: number;
  exp?: number;
}

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly MAX_ACTIVE_SESSIONS = 3;
  private readonly BCRYPT_ROUNDS = 12;

  constructor(
    @Inject(DATABASE_TOKEN) private readonly db: ReturnType<typeof import('drizzle-orm/postgres-js').drizzle>,
    @InjectRedis() private readonly redis: Redis,
    private readonly jwtService: JwtService,
    private readonly config: ConfigService,
    private readonly otpService: OtpService,
  ) {}

  // ── OTP Flow ────────────────────────────────────────────────

  async sendOtp(
    identifier: string,
    type: schema.OtpType = 'login',
    ipAddress?: string,
  ): Promise<{ sent: boolean; via: 'whatsapp' | 'email' }> {
    // Rate limit: max 3 per identifier per hour
    const rateLimitKey = `otp:rate:${identifier}`;
    const attempts = await this.redis.incr(rateLimitKey);
    if (attempts === 1) {
      await this.redis.expire(rateLimitKey, 3600);
    }
    if (attempts > 3) {
      throw new ForbiddenException({
        code: 'OTP_RATE_LIMITED',
        message: 'لقد تجاوزت الحد الأقصى لطلبات الرمز. حاول مرة أخرى بعد ساعة.',
      });
    }

    // Find user if exists
    const isPhone = identifier.startsWith('+');
    let userId: string | undefined;

    if (isPhone) {
      // Validate phone number
      try {
        const parsed = parsePhoneNumber(identifier);
        if (!parsed.isValid()) throw new Error('Invalid');
      } catch {
        throw new BadRequestException({ code: 'INVALID_PHONE', message: 'رقم الهاتف غير صحيح' });
      }

      const existing = await this.db.query.users.findFirst({
        where: eq(schema.users.phone, identifier),
        columns: { id: true },
      });
      userId = existing?.id;
    }

    // Generate + store OTP
    const { code, hash } = this.otpService.generate();
    await this.db.insert(schema.otpCodes).values({
      id: randomUUID(),
      userId: userId ?? null,
      identifier,
      codeHash: hash,
      type,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
      ipAddress: ipAddress ?? null,
    });

    // Deliver via WhatsApp (primary) or email (fallback)
    const via = isPhone ? 'whatsapp' : 'email';
    // Delivery happens via queue in production
    this.logger.log(`OTP sent to ${identifier} via ${via}: ${code}`);

    return { sent: true, via };
  }

  async verifyOtp(
    identifier: string,
    code: string,
    type: schema.OtpType = 'login',
    ipAddress?: string,
    deviceFingerprint?: string,
    deviceName?: string,
    deviceOs?: string,
  ): Promise<{ user: typeof schema.users.$inferSelect; tokens: TokenPair; isNewUser: boolean }> {
    // Find most recent valid OTP
    const otpRecord = await this.db.query.otpCodes.findFirst({
      where: and(
        eq(schema.otpCodes.identifier, identifier),
        eq(schema.otpCodes.type, type),
        eq(schema.otpCodes.isUsed, false),
      ),
      orderBy: (codes, { desc }) => [desc(codes.createdAt)],
    });

    if (!otpRecord) {
      throw new UnauthorizedException({ code: 'INVALID_OTP', message: 'الرمز غير صحيح أو منتهي الصلاحية' });
    }

    // Check expiry
    if (new Date() > otpRecord.expiresAt) {
      throw new UnauthorizedException({ code: 'OTP_EXPIRED', message: 'انتهت صلاحية الرمز. اطلب رمزاً جديداً.' });
    }

    // Check attempts
    if (otpRecord.attempts >= 3) {
      throw new ForbiddenException({ code: 'OTP_TOO_MANY_ATTEMPTS', message: 'تجاوزت عدد المحاولات. انتظر 30 دقيقة.' });
    }

    // Verify hash
    const isValid = this.otpService.verify(code, otpRecord.codeHash);
    if (!isValid) {
      await this.db
        .update(schema.otpCodes)
        .set({ attempts: otpRecord.attempts + 1 })
        .where(eq(schema.otpCodes.id, otpRecord.id));
      throw new UnauthorizedException({ code: 'INVALID_OTP', message: 'الرمز غير صحيح' });
    }

    // Mark OTP as used
    await this.db
      .update(schema.otpCodes)
      .set({ isUsed: true, usedAt: new Date() })
      .where(eq(schema.otpCodes.id, otpRecord.id));

    // Get or create user
    const isPhone = identifier.startsWith('+');
    const { user, isNewUser } = await this.getOrCreateUserByPhone(identifier, isPhone);

    // Check account status
    if (user.isDeleted) {
      throw new ForbiddenException({ code: 'ACCOUNT_DELETED', message: 'هذا الحساب محذوف' });
    }
    if (user.isFrozen) {
      throw new ForbiddenException({ code: 'ACCOUNT_FROZEN', message: 'هذا الحساب مجمد. تواصل مع الدعم.' });
    }

    const tokens = await this.createSession(user, ipAddress, deviceFingerprint, deviceName, deviceOs);
    return { user, tokens, isNewUser };
  }

  async googleAuth(
    googleId: string,
    email: string,
    name: string,
    avatarUrl?: string,
    ipAddress?: string,
    deviceFingerprint?: string,
  ): Promise<{ user: typeof schema.users.$inferSelect; tokens: TokenPair; isNewUser: boolean }> {
    // Find or create by google ID
    let user = await this.db.query.users.findFirst({
      where: eq(schema.users.googleId, googleId),
    });

    let isNewUser = false;
    if (!user) {
      // Try by email
      user = await this.db.query.users.findFirst({
        where: eq(schema.users.email, email),
      });

      if (user) {
        // Link Google to existing account
        await this.db
          .update(schema.users)
          .set({ googleId, emailVerified: true })
          .where(eq(schema.users.id, user.id));
      } else {
        // Create new user
        isNewUser = true;
        const sawaId = await this.generateUniqueSawaId();
        const username = await this.generateUniqueUsername(name);
        const isFounder = await this.isFounderUser();

        const [newUser] = await this.db
          .insert(schema.users)
          .values({
            id: randomUUID(),
            fullName: name,
            googleId,
            email,
            emailVerified: true,
            sawaId,
            username,
            avatarUrl: avatarUrl ?? null,
            trustScore: 60,
            isFounder,
          })
          .returning();
        user = newUser!;
      }
    }

    if (!user) throw new UnauthorizedException('Authentication failed');
    if (user.isDeleted) throw new ForbiddenException({ code: 'ACCOUNT_DELETED' });
    if (user.isFrozen) throw new ForbiddenException({ code: 'ACCOUNT_FROZEN' });

    const tokens = await this.createSession(user, ipAddress, deviceFingerprint);
    return { user, tokens, isNewUser };
  }

  async refreshTokens(refreshToken: string, ipAddress?: string): Promise<TokenPair> {
    const hash = this.hashToken(refreshToken);

    const session = await this.db.query.sessions.findFirst({
      where: eq(schema.sessions.refreshTokenHash, hash),
    });

    if (!session || new Date() > session.expiresAt) {
      throw new UnauthorizedException({ code: 'SESSION_EXPIRED', message: 'انتهت جلستك. سجل دخولك مرة أخرى.' });
    }

    const user = await this.db.query.users.findFirst({
      where: eq(schema.users.id, session.userId),
    });

    if (!user || user.isDeleted || user.isFrozen) {
      await this.db.delete(schema.sessions).where(eq(schema.sessions.id, session.id));
      throw new ForbiddenException({ code: 'ACCOUNT_UNAVAILABLE' });
    }

    // Rotate refresh token
    const newRefreshToken = randomUUID();
    const newHash = this.hashToken(newRefreshToken);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    await this.db
      .update(schema.sessions)
      .set({
        refreshTokenHash: newHash,
        expiresAt,
        lastActiveAt: new Date(),
        ipAddress: ipAddress ?? session.ipAddress,
      })
      .where(eq(schema.sessions.id, session.id));

    return this.generateTokens(user, session.id, newRefreshToken, expiresAt);
  }

  async logout(sessionId: string): Promise<void> {
    await this.db.delete(schema.sessions).where(eq(schema.sessions.id, sessionId));
  }

  async logoutAll(userId: string): Promise<void> {
    await this.db.delete(schema.sessions).where(eq(schema.sessions.userId, userId));
  }

  // ── Private Helpers ─────────────────────────────────────────

  private async createSession(
    user: typeof schema.users.$inferSelect,
    ipAddress?: string,
    deviceFingerprint?: string,
    deviceName?: string,
    deviceOs?: string,
  ): Promise<TokenPair> {
    // Enforce max 3 active sessions
    const activeSessions = await this.db.query.sessions.findMany({
      where: eq(schema.sessions.userId, user.id),
      orderBy: (s, { asc }) => [asc(s.lastActiveAt)],
    });

    if (activeSessions.length >= this.MAX_ACTIVE_SESSIONS) {
      // Delete oldest session
      const oldest = activeSessions[0];
      if (oldest) {
        await this.db.delete(schema.sessions).where(eq(schema.sessions.id, oldest.id));
      }
    }

    const sessionId = randomUUID();
    const refreshToken = randomUUID();
    const refreshHash = this.hashToken(refreshToken);
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    await this.db.insert(schema.sessions).values({
      id: sessionId,
      userId: user.id,
      refreshTokenHash: refreshHash,
      deviceFingerprint: deviceFingerprint ?? null,
      deviceName: deviceName ?? null,
      deviceOs: deviceOs ?? null,
      ipAddress: ipAddress ?? null,
      expiresAt,
    });

    // Update last active
    await this.db
      .update(schema.users)
      .set({ lastActiveAt: new Date() })
      .where(eq(schema.users.id, user.id));

    return this.generateTokens(user, sessionId, refreshToken, expiresAt);
  }

  private generateTokens(
    user: typeof schema.users.$inferSelect,
    sessionId: string,
    refreshToken: string,
    expiresAt: Date,
  ): TokenPair {
    const payload: JwtPayload = {
      sub: user.id,
      role: user.role,
      sessionId,
    };

    const accessToken = this.jwtService.sign(payload);

    return {
      accessToken,
      refreshToken,
      expiresAt: expiresAt.toISOString(),
    };
  }

  private async getOrCreateUserByPhone(
    phone: string,
    isPhone: boolean,
  ): Promise<{ user: typeof schema.users.$inferSelect; isNewUser: boolean }> {
    if (!isPhone) {
      throw new BadRequestException('Invalid identifier');
    }

    const existing = await this.db.query.users.findFirst({
      where: eq(schema.users.phone, phone),
    });

    if (existing) {
      return { user: existing, isNewUser: false };
    }

    // Create stub user — will complete profile in onboarding
    const sawaId = await this.generateUniqueSawaId();
    const isFounder = await this.isFounderUser();

    const [newUser] = await this.db
      .insert(schema.users)
      .values({
        id: randomUUID(),
        fullName: 'مستخدم جديد',
        phone,
        sawaId,
        trustScore: 60,
        isFounder,
        verificationLevel: 'basic',
      })
      .returning();

    return { user: newUser!, isNewUser: true };
  }

  private async generateUniqueSawaId(): Promise<string> {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let sawaId: string;
    let exists = true;

    while (exists) {
      const part1 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      const part2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
      sawaId = `SAWA-${part1}-${part2}`;

      const found = await this.db.query.users.findFirst({
        where: eq(schema.users.sawaId, sawaId),
        columns: { id: true },
      });
      exists = !!found;
    }

    return sawaId!;
  }

  private async generateUniqueUsername(name: string): Promise<string> {
    const base = name
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '')
      .slice(0, 15) || 'user';

    let username = base;
    let suffix = 1;

    while (true) {
      const found = await this.db.query.users.findFirst({
        where: eq(schema.users.username, username),
        columns: { id: true },
      });
      if (!found) break;
      username = `${base}${suffix++}`;
    }

    return `${username}.sawa`;
  }

  private async isFounderUser(): Promise<boolean> {
    const [result] = await this.db
      .select({ count: count() })
      .from(schema.users);
    return (result?.count ?? 0) < 1000;
  }

  private hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  async validateJwt(payload: JwtPayload): Promise<typeof schema.users.$inferSelect | null> {
    const user = await this.db.query.users.findFirst({
      where: eq(schema.users.id, payload.sub),
    });
    if (!user || user.isDeleted || user.isFrozen) return null;
    return user;
  }
}

  async checkUsernameAvailability(username: string): Promise<{ available: boolean }> {
    const full = username.endsWith('.sawa') ? username : `${username}.sawa`;
    const found = await this.db.query.users.findFirst({
      where: eq(schema.users.username, full),
      columns: { id: true },
    });
    return { available: !found };
  }
