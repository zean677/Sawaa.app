/**
 * SAWA — OTP Service
 * SHA256 hashing (NOT bcrypt — too slow for OTP)
 * timingSafeEqual to prevent timing attacks
 */

import { Injectable } from '@nestjs/common';
import { createHash, timingSafeEqual, randomInt } from 'crypto';

@Injectable()
export class OtpService {
  generate(): { code: string; hash: string } {
    const code = String(randomInt(100000, 999999));
    const hash = this.hash(code);
    return { code, hash };
  }

  verify(code: string, storedHash: string): boolean {
    try {
      const inputHash = this.hash(code);
      const a = Buffer.from(inputHash, 'hex');
      const b = Buffer.from(storedHash, 'hex');
      if (a.length !== b.length) return false;
      return timingSafeEqual(a, b);
    } catch {
      return false;
    }
  }

  hash(code: string): string {
    return createHash('sha256').update(code).digest('hex');
  }
}
