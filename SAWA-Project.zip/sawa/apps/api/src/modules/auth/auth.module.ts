/**
 * SAWA — Auth Module
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PassportModule } from '@nestjs/passport';
import { ConfigService } from '@nestjs/config';
import { AuthController } from './auth.controller';
import { AuthService } from './auth.service';
import { OtpService } from './otp.service';
import { WhatsAppService } from './whatsapp.service';
import { JwtStrategy } from './strategies/jwt.strategy';
import { GoogleStrategy } from './strategies/google.strategy';
import { BullModule } from '@nestjs/bullmq';
import { QUEUES } from '../queues/queue.module';

@Module({
  imports: [
    PassportModule.register({ defaultStrategy: 'jwt' }),
    JwtModule.registerAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        privateKey: config.get<string>('auth.jwtPrivateKey'),
        publicKey: config.get<string>('auth.jwtPublicKey'),
        signOptions: {
          algorithm: 'RS256',
          expiresIn: config.get<string>('auth.jwtAccessExpires', '15m'),
          issuer: 'sawa.app',
          audience: 'sawa-mobile',
        },
        verifyOptions: {
          algorithms: ['RS256'],
          issuer: 'sawa.app',
          audience: 'sawa-mobile',
        },
      }),
    }),
    BullModule.registerQueue({ name: QUEUES.WHATSAPP }, { name: QUEUES.EMAIL }),
  ],
  controllers: [AuthController],
  providers: [AuthService, OtpService, WhatsAppService, JwtStrategy, GoogleStrategy],
  exports: [AuthService, JwtModule, PassportModule],
})
export class AuthModule {}
