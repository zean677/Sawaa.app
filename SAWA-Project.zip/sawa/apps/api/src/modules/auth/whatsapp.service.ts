/**
 * SAWA — WhatsApp Service
 * Meta Cloud API for OTP delivery
 * Falls back to email if WhatsApp fails
 */

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { QUEUES } from '../queues/queue.module';
import { createHmac, timingSafeEqual } from 'crypto';

@Injectable()
export class WhatsAppService {
  private readonly logger = new Logger(WhatsAppService.name);
  private readonly apiUrl: string;
  private readonly accessToken: string;
  private readonly phoneNumberId: string;
  private readonly webhookSecret: string;
  private readonly templateName: string;
  private readonly templateLanguage: string;

  constructor(
    private readonly config: ConfigService,
    @InjectQueue(QUEUES.WHATSAPP) private readonly whatsappQueue: Queue,
    @InjectQueue(QUEUES.EMAIL) private readonly emailQueue: Queue,
  ) {
    const wa = config.get<Record<string, string>>('auth.whatsapp') ?? {};
    this.accessToken = wa['accessToken'] ?? '';
    this.phoneNumberId = wa['phoneNumberId'] ?? '';
    this.webhookSecret = wa['webhookSecret'] ?? '';
    this.templateName = wa['otpTemplateName'] ?? 'sawa_otp';
    this.templateLanguage = wa['otpTemplateLanguage'] ?? 'ar';
    this.apiUrl = `https://graph.facebook.com/v19.0/${this.phoneNumberId}/messages`;
  }

  /**
   * Send OTP via WhatsApp — enqueues for reliable delivery with retry
   */
  async sendOtp(phone: string, code: string): Promise<void> {
    await this.whatsappQueue.add(
      'send-otp',
      { phone, code, templateName: this.templateName },
      {
        attempts: 3,
        backoff: { type: 'exponential', delay: 2000 },
        removeOnComplete: true,
        removeOnFail: { age: 86400 },
      },
    );
  }

  /**
   * Actually sends via Meta Cloud API — called by the worker
   */
  async deliverOtpViaApi(phone: string, code: string): Promise<boolean> {
    if (!this.accessToken || !this.phoneNumberId) {
      this.logger.warn('WhatsApp not configured — skipping delivery (dev mode)');
      this.logger.debug(`DEV OTP for ${phone}: ${code}`);
      return true;
    }

    try {
      const body = {
        messaging_product: 'whatsapp',
        to: phone.replace('+', ''),
        type: 'template',
        template: {
          name: this.templateName,
          language: { code: this.templateLanguage },
          components: [
            {
              type: 'body',
              parameters: [{ type: 'text', text: code }],
            },
            {
              type: 'button',
              sub_type: 'url',
              index: '0',
              parameters: [{ type: 'text', text: code }],
            },
          ],
        },
      };

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
      });

      if (!response.ok) {
        const err = await response.text();
        this.logger.error(`WhatsApp API error: ${response.status} — ${err}`);
        return false;
      }

      return true;
    } catch (err) {
      this.logger.error(`WhatsApp delivery failed: ${String(err)}`);
      return false;
    }
  }

  /**
   * Fallback: send OTP via email
   */
  async sendOtpViaEmail(email: string, code: string): Promise<void> {
    await this.emailQueue.add('send-otp', {
      to: email,
      subject: 'رمز التحقق من SAWA',
      templateId: 'otp',
      variables: { code, expiryMinutes: 10 },
    });
  }

  /**
   * Verify WhatsApp webhook signature (HMAC SHA256)
   * MUST be called before processing any webhook
   */
  verifyWebhookSignature(rawBody: string, signature: string): boolean {
    if (!this.webhookSecret) return false;
    try {
      const expected = createHmac('sha256', this.webhookSecret)
        .update(rawBody)
        .digest('hex');
      const sig = signature.replace('sha256=', '');
      const a = Buffer.from(expected, 'hex');
      const b = Buffer.from(sig, 'hex');
      if (a.length !== b.length) return false;
      return timingSafeEqual(a, b);
    } catch {
      return false;
    }
  }

  /**
   * Verify webhook challenge (GET request from Meta)
   */
  verifyWebhookChallenge(
    mode: string,
    token: string,
    challenge: string,
  ): string | null {
    if (mode === 'subscribe' && token === this.webhookSecret) {
      return challenge;
    }
    return null;
  }
}
