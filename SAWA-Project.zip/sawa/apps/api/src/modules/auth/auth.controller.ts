/**
 * SAWA — Auth Controller
 * All authentication endpoints
 */

import {
  Controller,
  Post,
  Get,
  Body,
  Req,
  Res,
  UseGuards,
  HttpCode,
  HttpStatus,
  Delete,
  Query,
  Headers,
  RawBodyRequest,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { FastifyRequest, FastifyReply } from 'fastify';
import { IsString, IsOptional, IsIn, Length, Matches } from 'class-validator';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from '../../common/guards/auth.guard';
import { CurrentUser, Public, RequestId } from '../../common/guards/auth.guard';

class SendOtpDto {
  @IsString()
  identifier!: string; // phone (+963...) or email
}

class VerifyOtpDto {
  @IsString()
  identifier!: string;

  @IsString()
  @Length(6, 6)
  code!: string;

  @IsOptional()
  @IsString()
  deviceFingerprint?: string;

  @IsOptional()
  @IsString()
  deviceName?: string;

  @IsOptional()
  @IsString()
  deviceOs?: string;
}

class RegisterDto {
  @IsString()
  @Length(2, 100)
  fullName!: string;

  @IsString()
  @Matches(/^[a-z0-9.]{3,20}$/)
  username!: string;

  @IsString()
  @IsIn(['silver', 'gold', 'black', 'violet', 'neon_blue'])
  cardColor!: string;

  @IsOptional()
  @IsString()
  @IsIn(['ar', 'en'])
  language?: string;
}

class RefreshTokenDto {
  @IsString()
  refreshToken!: string;
}

class CheckUsernameDto {
  @IsString()
  @Matches(/^[a-z0-9.]{3,20}$/)
  username!: string;
}

@ApiTags('auth')
@Controller({ path: 'auth', version: '1' })
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('send-otp')
  @HttpCode(HttpStatus.OK)
  @Throttle({ otp: { ttl: 3600000, limit: 3 } })
  @ApiOperation({ summary: 'Send OTP via WhatsApp or Email' })
  async sendOtp(
    @Body() dto: SendOtpDto,
    @Req() req: FastifyRequest,
  ) {
    const ip = req.ip;
    const result = await this.authService.sendOtp(dto.identifier, 'login', ip);
    return {
      success: true,
      data: {
        sent: result.sent,
        via: result.via,
        message: result.via === 'whatsapp'
          ? 'تم إرسال رمز التحقق عبر واتساب'
          : 'تم إرسال رمز التحقق عبر البريد الإلكتروني',
      },
    };
  }

  @Public()
  @Post('verify-otp')
  @HttpCode(HttpStatus.OK)
  @Throttle({ auth: { ttl: 900000, limit: 5 } })
  @ApiOperation({ summary: 'Verify OTP and get tokens' })
  async verifyOtp(
    @Body() dto: VerifyOtpDto,
    @Req() req: FastifyRequest,
  ) {
    const result = await this.authService.verifyOtp(
      dto.identifier,
      dto.code,
      'login',
      req.ip,
      dto.deviceFingerprint,
      dto.deviceName,
      dto.deviceOs,
    );

    return {
      success: true,
      data: {
        accessToken: result.tokens.accessToken,
        refreshToken: result.tokens.refreshToken,
        expiresAt: result.tokens.expiresAt,
        isNewUser: result.isNewUser,
        user: this.sanitizeUser(result.user),
      },
    };
  }

  @Public()
  @Get('google')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Initiate Google OAuth' })
  googleAuth(): void {
    // Guard handles redirect
  }

  @Public()
  @Get('google/callback')
  @UseGuards(AuthGuard('google'))
  @ApiOperation({ summary: 'Google OAuth callback' })
  async googleCallback(
    @Req() req: FastifyRequest & { user: { googleId: string; email: string; name: string; avatarUrl?: string } },
    @Res() res: FastifyReply,
  ) {
    const { googleId, email, name, avatarUrl } = req.user;
    const result = await this.authService.googleAuth(
      googleId,
      email,
      name,
      avatarUrl,
      req.ip,
    );

    // Redirect to mobile app deep link with tokens
    const params = new URLSearchParams({
      access_token: result.tokens.accessToken,
      refresh_token: result.tokens.refreshToken,
      is_new_user: String(result.isNewUser),
    });

    void res.redirect(302, `sawa://auth/callback?${params.toString()}`);
  }

  @Public()
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Refresh access token' })
  async refresh(
    @Body() dto: RefreshTokenDto,
    @Req() req: FastifyRequest,
  ) {
    const tokens = await this.authService.refreshTokens(dto.refreshToken, req.ip);
    return {
      success: true,
      data: {
        accessToken: tokens.accessToken,
        refreshToken: tokens.refreshToken,
        expiresAt: tokens.expiresAt,
      },
    };
  }

  @UseGuards(JwtAuthGuard)
  @Delete('logout')
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Logout current device' })
  async logout(@CurrentUser('sessionId') sessionId: string) {
    await this.authService.logout(sessionId);
    return { success: true, data: { message: 'تم تسجيل الخروج بنجاح' } };
  }

  @UseGuards(JwtAuthGuard)
  @Delete('logout-all')
  @HttpCode(HttpStatus.OK)
  @ApiBearerAuth('JWT')
  @ApiOperation({ summary: 'Logout all devices' })
  async logoutAll(@CurrentUser('id') userId: string) {
    await this.authService.logoutAll(userId);
    return { success: true, data: { message: 'تم تسجيل الخروج من جميع الأجهزة' } };
  }

  @Public()
  @Get('check-username')
  @ApiOperation({ summary: 'Check if username is available' })
  async checkUsername(@Query() query: CheckUsernameDto) {
    const { available } = await this.authService.checkUsernameAvailability(
      query.username,
    );
    return {
      success: true,
      data: {
        username: `${query.username}.sawa`,
        available,
        message: available ? 'اسم المستخدم متاح' : 'اسم المستخدم مأخوذ',
      },
    };
  }

  @Public()
  @Get('whatsapp/webhook')
  @ApiOperation({ summary: 'WhatsApp webhook verification' })
  whatsappWebhookVerify(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: FastifyReply,
  ) {
    const webhookSecret = process.env['WHATSAPP_WEBHOOK_SECRET'] ?? '';
    if (mode === 'subscribe' && token === webhookSecret) {
      void res.status(200).send(challenge);
    } else {
      void res.status(403).send('Forbidden');
    }
  }

  @Public()
  @Post('whatsapp/webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'WhatsApp webhook receiver' })
  whatsappWebhook(
    @Headers('x-hub-signature-256') signature: string,
    @Body() body: unknown,
  ) {
    // Signature verification done in service
    // Delivery status updates handled here
    return { success: true };
  }

  private sanitizeUser(user: Record<string, unknown>) {
    const { passwordHash, ...safe } = user;
    void passwordHash;
    return safe;
  }
}
