import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy, Profile, VerifyCallback } from 'passport-google-oauth20';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class GoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor(config: ConfigService) {
    super({
      clientID: config.get<string>('auth.google.clientId') ?? '',
      clientSecret: config.get<string>('auth.google.clientSecret') ?? '',
      callbackURL: `${config.get<string>('app.url')}/api/v1/auth/google/callback`,
      scope: ['email', 'profile'],
    });
  }

  validate(
    accessToken: string,
    refreshToken: string,
    profile: Profile,
    done: VerifyCallback,
  ): void {
    const { id, displayName, emails, photos } = profile;
    done(null, {
      googleId: id,
      email: emails?.[0]?.value ?? '',
      name: displayName,
      avatarUrl: photos?.[0]?.value ?? null,
    });
  }
}
