/**
 * SAWA — Redis Module
 * Shared Redis connection for caching + BullMQ queues
 */

import { Module, Global } from '@nestjs/common';
import { RedisModule as NestRedisModule } from '@nestjs-modules/ioredis';
import { ConfigService } from '@nestjs/config';

@Global()
@Module({
  imports: [
    NestRedisModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        type: 'single',
        url: config.get<string>('redis.url') ?? 'redis://localhost:6379',
        options: {
          maxRetriesPerRequest: 3,
          retryStrategy: (times: number) => Math.min(times * 100, 3000),
          lazyConnect: false,
          enableReadyCheck: true,
          enableOfflineQueue: true,
          connectTimeout: 10000,
          commandTimeout: 5000,
        },
      }),
    }),
  ],
  exports: [NestRedisModule],
})
export class RedisModule {}
