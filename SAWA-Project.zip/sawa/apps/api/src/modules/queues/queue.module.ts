/**
 * SAWA — Queue Module
 * All 14 BullMQ queues registered and configured
 */

import { Module, Global } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { ConfigService } from '@nestjs/config';

export const QUEUES = {
  NOTIFICATIONS: 'notifications',
  IMAGE_PROCESSING: 'image-processing',
  AI_MODERATION: 'ai-moderation',
  FRAUD_DETECTION: 'fraud-detection',
  ESCROW_AUTO_RELEASE: 'escrow-auto-release',
  POST_EXPIRY: 'post-expiry',
  RECONCILIATION: 'reconciliation',
  BALANCE_SNAPSHOT: 'balance-snapshot',
  TRUST_SCORE_UPDATE: 'trust-score-update',
  EMAIL: 'email',
  WHATSAPP: 'whatsapp',
  PREMIUM_RENEWAL: 'premium-renewal',
  DATA_CLEANUP: 'data-cleanup',
  KYC_REMINDER: 'kyc-reminder',
} as const;

export type QueueName = (typeof QUEUES)[keyof typeof QUEUES];

const QUEUE_CONFIGS = Object.values(QUEUES).map((name) => ({
  name,
  defaultJobOptions: {
    removeOnComplete: { age: 86400, count: 1000 }, // keep 24h or 1000 jobs
    removeOnFail: { age: 7 * 86400 },              // keep failed 7 days
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
  },
}));

@Global()
@Module({
  imports: [
    BullModule.forRootAsync({
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        connection: {
          url: config.get<string>('redis.url') ?? 'redis://localhost:6379',
        },
        prefix: 'sawa',
      }),
    }),
    BullModule.registerQueue(...QUEUE_CONFIGS),
  ],
  exports: [BullModule],
})
export class QueueModule {}
