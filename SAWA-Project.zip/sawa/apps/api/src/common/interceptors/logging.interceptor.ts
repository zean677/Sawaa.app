import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { FastifyRequest } from 'fastify';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const http = context.switchToHttp();
    const request = http.getRequest<FastifyRequest & { requestId?: string }>();
    const { method, url, requestId } = request;
    const start = Date.now();

    return next.handle().pipe(
      tap({
        next: () => {
          const ms = Date.now() - start;
          this.logger.log(`[${requestId ?? '?'}] ${method} ${url} → ${ms}ms`);
        },
        error: () => {
          const ms = Date.now() - start;
          this.logger.warn(`[${requestId ?? '?'}] ${method} ${url} ERROR → ${ms}ms`);
        },
      }),
    );
  }
}
