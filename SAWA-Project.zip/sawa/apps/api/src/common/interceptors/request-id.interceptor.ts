/**
 * SAWA — Request ID Interceptor
 * Injects X-Request-ID on every request/response
 */

import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { FastifyRequest, FastifyReply } from 'fastify';
import { randomUUID } from 'crypto';

@Injectable()
export class RequestIdInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const http = context.switchToHttp();
    const request = http.getRequest<FastifyRequest>();
    const response = http.getResponse<FastifyReply>();

    const requestId =
      (request.headers['x-request-id'] as string) ?? randomUUID();

    // Attach to request for use in filters/services
    (request as FastifyRequest & { requestId: string }).requestId = requestId;

    return next.handle().pipe(
      tap(() => {
        void response.header('X-Request-ID', requestId);
        void response.header('X-API-Version', '1');
      }),
    );
  }
}
