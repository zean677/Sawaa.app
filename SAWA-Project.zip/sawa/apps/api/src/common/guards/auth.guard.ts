/**
 * SAWA — Guards & Decorators
 */

import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  UnauthorizedException,
  SetMetadata,
  createParamDecorator,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Reflector } from '@nestjs/core';
import { ConfigService } from '@nestjs/config';

// ── JWT Guard ─────────────────────────────────────────────────
@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  override handleRequest<T>(err: Error, user: T): T {
    if (err || !user) {
      throw new UnauthorizedException({
        code: 'UNAUTHORIZED',
        message: 'يجب تسجيل الدخول أولاً',
      });
    }
    return user;
  }
}

// ── Roles ─────────────────────────────────────────────────────
export const ROLES_KEY = 'roles';
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);

// ── Roles Guard ───────────────────────────────────────────────
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!requiredRoles || requiredRoles.length === 0) return true;

    const { user } = context.switchToHttp().getRequest<{ user: { role: string } }>();
    if (!user) {
      throw new UnauthorizedException({ code: 'UNAUTHORIZED' });
    }

    const roleHierarchy: Record<string, number> = {
      user: 0,
      agent: 1,
      support: 2,
      moderator: 3,
      admin: 4,
      super_admin: 5,
    };

    const userLevel = roleHierarchy[user.role] ?? 0;
    const hasRole = requiredRoles.some(
      (role) => userLevel >= (roleHierarchy[role] ?? 99),
    );

    if (!hasRole) {
      throw new ForbiddenException({
        code: 'FORBIDDEN',
        message: 'ليس لديك صلاحية للوصول',
      });
    }

    return true;
  }
}

// ── Admin IP Whitelist Guard ───────────────────────────────────
@Injectable()
export class AdminIpGuard implements CanActivate {
  private readonly whitelist: string[];

  constructor(private readonly config: ConfigService) {
    this.whitelist = config.get<string[]>('services.security.adminIpWhitelist') ?? [];
  }

  canActivate(context: ExecutionContext): boolean {
    if (this.whitelist.length === 0) return true;

    const request = context.switchToHttp().getRequest<{ ip: string; headers: Record<string, string> }>();
    const ip = request.headers['x-forwarded-for']?.split(',')[0]?.trim() ?? request.ip;

    if (!this.whitelist.includes(ip)) {
      throw new ForbiddenException({
        code: 'IP_NOT_ALLOWED',
        message: 'Access denied from this IP address',
      });
    }

    return true;
  }
}

// ── Current User Decorator ────────────────────────────────────
export const CurrentUser = createParamDecorator(
  (data: string | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest<{ user: Record<string, unknown> }>();
    return data ? request.user?.[data] : request.user;
  },
);

// ── Request ID Decorator ──────────────────────────────────────
export const RequestId = createParamDecorator(
  (_: unknown, ctx: ExecutionContext): string => {
    const request = ctx.switchToHttp().getRequest<{ requestId?: string }>();
    return request.requestId ?? 'unknown';
  },
);

// ── Idempotency Key Decorator ─────────────────────────────────
export const IdempotencyKey = createParamDecorator(
  (_: unknown, ctx: ExecutionContext): string | undefined => {
    const request = ctx.switchToHttp().getRequest<{ headers: Record<string, string> }>();
    return request.headers['x-idempotency-key'];
  },
);

// ── Public route marker ───────────────────────────────────────
export const IS_PUBLIC_KEY = 'isPublic';
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
