/**
 * SAWA — Global Exception Filter
 * Handles all unhandled exceptions, formats responses consistently
 */

import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { FastifyReply, FastifyRequest } from 'fastify';
import { ZodError } from 'zod';

interface ErrorResponse {
  success: false;
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
  requestId?: string;
  timestamp: string;
}

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);
  private readonly isDevelopment: boolean;

  constructor(private readonly config: ConfigService) {
    this.isDevelopment = config.get('app.nodeEnv') === 'development';
  }

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<FastifyReply>();
    const request = ctx.getRequest<FastifyRequest>();

    const requestId = (request.headers['x-request-id'] as string) ?? 'unknown';
    const { status, errorResponse } = this.buildErrorResponse(exception, requestId);

    // Log appropriately based on severity
    if (status >= 500) {
      this.logger.error(
        `[${requestId}] ${request.method} ${request.url} → ${status}`,
        exception instanceof Error ? exception.stack : String(exception),
      );
    } else if (status >= 400) {
      this.logger.warn(
        `[${requestId}] ${request.method} ${request.url} → ${status}: ${errorResponse.error.message}`,
      );
    }

    void response.status(status).send(errorResponse);
  }

  private buildErrorResponse(
    exception: unknown,
    requestId: string,
  ): { status: number; errorResponse: ErrorResponse } {
    const timestamp = new Date().toISOString();

    // HttpException (most NestJS errors)
    if (exception instanceof HttpException) {
      const status = exception.getStatus();
      const exceptionResponse = exception.getResponse();

      let message: string;
      let details: unknown;

      if (typeof exceptionResponse === 'string') {
        message = exceptionResponse;
      } else if (typeof exceptionResponse === 'object' && exceptionResponse !== null) {
        const resp = exceptionResponse as Record<string, unknown>;
        message = (resp['message'] as string) || exception.message;
        details = this.isDevelopment ? resp['details'] : undefined;
      } else {
        message = exception.message;
      }

      return {
        status,
        errorResponse: {
          success: false,
          error: {
            code: this.httpStatusToCode(status),
            message: this.sanitizeMessage(message),
            details: this.isDevelopment ? details : undefined,
          },
          requestId,
          timestamp,
        },
      };
    }

    // ZodError (validation)
    if (exception instanceof ZodError) {
      return {
        status: HttpStatus.UNPROCESSABLE_ENTITY,
        errorResponse: {
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request data',
            details: this.isDevelopment ? exception.errors : undefined,
          },
          requestId,
          timestamp,
        },
      };
    }

    // Unknown errors — never expose internals in production
    return {
      status: HttpStatus.INTERNAL_SERVER_ERROR,
      errorResponse: {
        success: false,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message: 'An unexpected error occurred',
          details: this.isDevelopment
            ? { message: (exception as Error)?.message }
            : undefined,
        },
        requestId,
        timestamp,
      },
    };
  }

  private httpStatusToCode(status: number): string {
    const codes: Record<number, string> = {
      400: 'BAD_REQUEST',
      401: 'UNAUTHORIZED',
      403: 'FORBIDDEN',
      404: 'NOT_FOUND',
      409: 'CONFLICT',
      422: 'VALIDATION_ERROR',
      429: 'RATE_LIMITED',
      503: 'SERVICE_UNAVAILABLE',
    };
    return codes[status] ?? 'HTTP_ERROR';
  }

  private sanitizeMessage(message: string | string[]): string {
    if (Array.isArray(message)) {
      return message[0] ?? 'An error occurred';
    }
    return message;
  }
}
