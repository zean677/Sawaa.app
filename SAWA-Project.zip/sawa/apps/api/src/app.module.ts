import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { APP_GUARD } from '@nestjs/core';

// Config
import appConfig from './config/app.config';
import databaseConfig from './config/database.config';
import redisConfig from './config/redis.config';
import authConfig from './config/auth.config';
import storageConfig from './config/storage.config';
import servicesConfig from './config/services.config';

// Core Modules
import { DatabaseModule } from './database/database.module';
import { RedisModule } from './modules/queues/redis.module';
import { QueueModule } from './modules/queues/queue.module';

// Feature Modules
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { WalletModule } from './modules/wallet/wallet.module';
import { LedgerModule } from './modules/ledger/ledger.module';
import { EscrowModule } from './modules/escrow/escrow.module';
import { MarketModule } from './modules/market/market.module';
import { AgentsModule } from './modules/agents/agents.module';
import { ChatModule } from './modules/chat/chat.module';
import { TrustModule } from './modules/trust/trust.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { PremiumModule } from './modules/premium/premium.module';
import { AiModule } from './modules/ai/ai.module';
import { AdminModule } from './modules/admin/admin.module';

@Module({
  imports: [
    // ── Config ────────────────────────────────────────────────
    ConfigModule.forRoot({
      isGlobal: true,
      load: [
        appConfig,
        databaseConfig,
        redisConfig,
        authConfig,
        storageConfig,
        servicesConfig,
      ],
      expandVariables: true,
      cache: true,
    }),

    // ── Rate Limiting ──────────────────────────────────────────
    ThrottlerModule.forRootAsync({
      useFactory: () => ({
        throttlers: [
          { name: 'default', ttl: 60000, limit: 100 },
          { name: 'auth', ttl: 900000, limit: 5 },
          { name: 'otp', ttl: 3600000, limit: 3 },
          { name: 'transfer', ttl: 3600000, limit: 20 },
        ],
      }),
    }),

    // ── Event System ───────────────────────────────────────────
    EventEmitterModule.forRoot({
      wildcard: false,
      delimiter: '.',
      maxListeners: 20,
      verboseMemoryLeak: true,
    }),

    // ── Cron Jobs ──────────────────────────────────────────────
    ScheduleModule.forRoot(),

    // ── Infrastructure ─────────────────────────────────────────
    DatabaseModule,
    RedisModule,
    QueueModule,

    // ── Feature Modules ────────────────────────────────────────
    HealthModule,
    AuthModule,
    LedgerModule,    // must come before Wallet
    WalletModule,
    EscrowModule,
    MarketModule,
    AgentsModule,
    ChatModule,
    TrustModule,
    NotificationsModule,
    PremiumModule,
    AiModule,
    AdminModule,
  ],
  providers: [
    // Global rate limit guard
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
