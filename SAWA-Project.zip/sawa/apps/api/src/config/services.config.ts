import { registerAs } from '@nestjs/config';

export default registerAs('services', () => ({
  smtp: {
    host: process.env['SMTP_HOST'] ?? 'localhost',
    port: parseInt(process.env['SMTP_PORT'] ?? '1025', 10),
    secure: process.env['SMTP_SECURE'] === 'true',
    user: process.env['SMTP_USER'] ?? '',
    pass: process.env['SMTP_PASS'] ?? '',
    fromName: process.env['SMTP_FROM_NAME'] ?? 'SAWA',
    fromEmail: process.env['SMTP_FROM_EMAIL'] ?? 'noreply@sawa.app',
  },
  firebase: {
    projectId: process.env['FIREBASE_PROJECT_ID'] ?? '',
    clientEmail: process.env['FIREBASE_CLIENT_EMAIL'] ?? '',
    privateKey: (process.env['FIREBASE_PRIVATE_KEY'] ?? '').replace(/\\n/g, '\n'),
  },
  meilisearch: {
    url: process.env['MEILISEARCH_URL'] ?? 'http://localhost:7700',
    masterKey: process.env['MEILISEARCH_MASTER_KEY'] ?? '',
    apiKey: process.env['MEILISEARCH_API_KEY'] ?? '',
  },
  openai: {
    apiKey: process.env['OPENAI_API_KEY'] ?? '',
    model: process.env['OPENAI_MODEL'] ?? 'gpt-4o',
    moderationModel: process.env['OPENAI_MODERATION_MODEL'] ?? 'text-moderation-latest',
  },
  sentry: {
    dsn: process.env['SENTRY_DSN'] ?? '',
    environment: process.env['SENTRY_ENVIRONMENT'] ?? 'development',
    tracesSampleRate: parseFloat(process.env['SENTRY_TRACES_SAMPLE_RATE'] ?? '1.0'),
  },
  posthog: {
    apiKey: process.env['POSTHOG_API_KEY'] ?? '',
    host: process.env['POSTHOG_HOST'] ?? 'https://app.posthog.com',
  },
  security: {
    corsOrigins: process.env['CORS_ORIGINS'] ?? 'http://localhost:3001',
    adminIpWhitelist: (process.env['ADMIN_IP_WHITELIST'] ?? '127.0.0.1,::1')
      .split(',')
      .map((ip) => ip.trim()),
    encryptionKey: process.env['ENCRYPTION_KEY'] ?? '',
  },
}));
