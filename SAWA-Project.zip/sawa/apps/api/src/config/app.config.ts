import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  name: process.env['APP_NAME'] ?? 'SAWA',
  version: process.env['APP_VERSION'] ?? '1.0.0',
  minVersion: process.env['APP_MIN_VERSION'] ?? '1.0.0',
  nodeEnv: process.env['NODE_ENV'] ?? 'development',
  port: parseInt(process.env['PORT'] ?? '3000', 10),
  url: process.env['APP_URL'] ?? 'http://localhost:3000',
  webUrl: process.env['APP_WEB_URL'] ?? 'http://localhost:3001',
  isDevelopment: process.env['NODE_ENV'] === 'development',
  isProduction: process.env['NODE_ENV'] === 'production',
  isTest: process.env['NODE_ENV'] === 'test',
}));
