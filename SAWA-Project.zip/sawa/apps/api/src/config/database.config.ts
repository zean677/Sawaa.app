import { registerAs } from '@nestjs/config';

export default registerAs('database', () => ({
  url: process.env['DATABASE_URL'] ?? '',
  poolMax: parseInt(process.env['DATABASE_POOL_MAX'] ?? '20', 10),
  idleTimeoutMs: parseInt(process.env['DATABASE_POOL_IDLE_TIMEOUT_MS'] ?? '10000', 10),
  connectionTimeoutMs: parseInt(process.env['DATABASE_POOL_CONNECTION_TIMEOUT_MS'] ?? '5000', 10),
  ssl: process.env['DATABASE_SSL'] === 'true',
}));
