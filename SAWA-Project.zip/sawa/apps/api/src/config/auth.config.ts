import { registerAs } from '@nestjs/config';

export default registerAs('auth', () => ({
  jwtPrivateKey: (process.env['JWT_PRIVATE_KEY'] ?? '').replace(/\\n/g, '\n'),
  jwtPublicKey: (process.env['JWT_PUBLIC_KEY'] ?? '').replace(/\\n/g, '\n'),
  jwtAccessExpires: process.env['JWT_ACCESS_EXPIRES'] ?? '15m',
  jwtRefreshExpires: process.env['JWT_REFRESH_EXPIRES'] ?? '30d',
  otpSecret: process.env['OTP_SECRET'] ?? '',
  google: {
    clientId: process.env['GOOGLE_CLIENT_ID'] ?? '',
    clientSecret: process.env['GOOGLE_CLIENT_SECRET'] ?? '',
  },
  whatsapp: {
    accessToken: process.env['WHATSAPP_ACCESS_TOKEN'] ?? '',
    phoneNumberId: process.env['WHATSAPP_PHONE_NUMBER_ID'] ?? '',
    webhookSecret: process.env['WHATSAPP_WEBHOOK_SECRET'] ?? '',
    businessAccountId: process.env['WHATSAPP_BUSINESS_ACCOUNT_ID'] ?? '',
    otpTemplateName: process.env['WHATSAPP_OTP_TEMPLATE_NAME'] ?? 'sawa_otp',
    otpTemplateLanguage: process.env['WHATSAPP_OTP_TEMPLATE_LANGUAGE'] ?? 'ar',
  },
}));
