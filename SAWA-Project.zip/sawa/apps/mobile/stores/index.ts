/**
 * SAWA Mobile — Zustand Stores
 */

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';

// ── Secure Storage adapter for tokens ────────────────────────
const secureStorage = {
  async getToken(): Promise<string | null> { return SecureStore.getItemAsync('sawa_access_token'); },
  async setToken(token: string): Promise<void> { await SecureStore.setItemAsync('sawa_access_token', token); },
  async deleteToken(): Promise<void> { await SecureStore.deleteItemAsync('sawa_access_token'); },
  async getRefreshToken(): Promise<string | null> { return SecureStore.getItemAsync('sawa_refresh_token'); },
  async setRefreshToken(token: string): Promise<void> { await SecureStore.setItemAsync('sawa_refresh_token', token); },
  async deleteRefreshToken(): Promise<void> { await SecureStore.deleteItemAsync('sawa_refresh_token'); },
  async setPin(pin: string): Promise<void> { await SecureStore.setItemAsync('sawa_pin', pin); },
  async getPin(): Promise<string | null> { return SecureStore.getItemAsync('sawa_pin'); },
  async deletePin(): Promise<void> { await SecureStore.deleteItemAsync('sawa_pin'); },
};

export { secureStorage };

// ── Types ─────────────────────────────────────────────────────
export interface User {
  id: string;
  fullName: string;
  phone: string | null;
  email: string | null;
  sawaId: string | null;
  username: string | null;
  role: string;
  trustScore: number;
  verificationLevel: string;
  avatarUrl: string | null;
  isFrozen: boolean;
  isFounder: boolean;
  preferredLanguage: string;
}

export interface Wallet {
  availableBalance: string;
  frozenBalance: string;
  pendingBalance: string;
  cardType: string;
  cardColor: string;
  preferredCurrency: string;
  isFrozen: boolean;
  isPremium: boolean;
  premiumExpiresAt: string | null;
  totalTransactionsCount: number;
  equivalents: { syp: string; usd: string; eur: string };
}

// ── Auth Store ─────────────────────────────────────────────────
interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isOnboarded: boolean;
  accessToken: string | null;
  sessionId: string | null;
  setUser: (user: User) => void;
  setTokens: (accessToken: string, refreshToken: string) => Promise<void>;
  setOnboarded: (v: boolean) => void;
  logout: () => Promise<void>;
  updateUser: (partial: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,
      isOnboarded: false,
      accessToken: null,
      sessionId: null,

      setUser: (user) => set({ user, isAuthenticated: true }),

      setTokens: async (accessToken, refreshToken) => {
        await secureStorage.setToken(accessToken);
        await secureStorage.setRefreshToken(refreshToken);
        set({ accessToken, isAuthenticated: true });
      },

      setOnboarded: (v) => set({ isOnboarded: v }),

      logout: async () => {
        await secureStorage.deleteToken();
        await secureStorage.deleteRefreshToken();
        set({ user: null, isAuthenticated: false, accessToken: null, sessionId: null });
      },

      updateUser: (partial) => {
        const current = get().user;
        if (current) set({ user: { ...current, ...partial } });
      },
    }),
    {
      name: 'sawa-auth',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        isOnboarded: state.isOnboarded,
        user: state.user,
      }),
    },
  ),
);

// ── Wallet Store ───────────────────────────────────────────────
interface WalletState {
  wallet: Wallet | null;
  isLoading: boolean;
  lastSynced: string | null;
  setWallet: (wallet: Wallet) => void;
  setLoading: (v: boolean) => void;
  updateBalance: (available: string) => void;
  reset: () => void;
}

export const useWalletStore = create<WalletState>()((set) => ({
  wallet: null,
  isLoading: false,
  lastSynced: null,

  setWallet: (wallet) => set({ wallet, lastSynced: new Date().toISOString(), isLoading: false }),
  setLoading: (v) => set({ isLoading: v }),
  updateBalance: (available) =>
    set((state) => ({
      wallet: state.wallet ? { ...state.wallet, availableBalance: available } : state.wallet,
    })),
  reset: () => set({ wallet: null, isLoading: false, lastSynced: null }),
}));

// ── App Store ──────────────────────────────────────────────────
interface AppState {
  language: 'ar' | 'en';
  isRTL: boolean;
  isMaintenance: boolean;
  maintenanceMessage: string | null;
  forceUpdate: boolean;
  exchangeRates: { spToSyp: string; spToUsd: string; spToEur: string } | null;
  unreadNotifications: number;
  setLanguage: (lang: 'ar' | 'en') => void;
  setMaintenance: (active: boolean, message?: string) => void;
  setExchangeRates: (rates: { spToSyp: string; spToUsd: string; spToEur: string }) => void;
  setUnreadNotifications: (count: number) => void;
  incrementUnread: () => void;
  decrementUnread: (by?: number) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      language: 'ar',
      isRTL: true,
      isMaintenance: false,
      maintenanceMessage: null,
      forceUpdate: false,
      exchangeRates: null,
      unreadNotifications: 0,

      setLanguage: (lang) => set({ language: lang, isRTL: lang === 'ar' }),
      setMaintenance: (active, message) => set({ isMaintenance: active, maintenanceMessage: message ?? null }),
      setExchangeRates: (rates) => set({ exchangeRates: rates }),
      setUnreadNotifications: (count) => set({ unreadNotifications: count }),
      incrementUnread: () => set((s) => ({ unreadNotifications: s.unreadNotifications + 1 })),
      decrementUnread: (by = 1) => set((s) => ({ unreadNotifications: Math.max(0, s.unreadNotifications - by) })),
    }),
    {
      name: 'sawa-app',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ language: state.language, isRTL: state.isRTL }),
    },
  ),
);

// ── Notification Store ────────────────────────────────────────
interface NotificationState {
  fcmToken: string | null;
  setFcmToken: (token: string) => void;
}

export const useNotificationStore = create<NotificationState>()((set) => ({
  fcmToken: null,
  setFcmToken: (token) => set({ fcmToken: token }),
}));
