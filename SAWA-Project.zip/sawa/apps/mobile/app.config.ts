import { ExpoConfig, ConfigContext } from 'expo/config';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: 'SAWA',
  slug: 'sawa',
  version: '1.0.0',
  orientation: 'portrait',
  scheme: 'sawa',
  userInterfaceStyle: 'dark',
  icon: './assets/icon.png',
  splash: {
    image: './assets/splash.png',
    resizeMode: 'contain',
    backgroundColor: '#08080F',
  },
  updates: {
    fallbackToCacheTimeout: 0,
    url: 'https://u.expo.dev/YOUR_EAS_PROJECT_ID',
  },
  assetBundlePatterns: ['**/*'],
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.sawa.app',
    buildNumber: '1',
    deploymentTarget: '16.0',
    infoPlist: {
      NSCameraUsageDescription: 'SAWA يحتاج الكاميرا للصور الشخصية والتحقق من الهوية',
      NSPhotoLibraryUsageDescription: 'SAWA يحتاج الوصول للصور لرفع إثباتات الدفع',
      NSLocationWhenInUseUsageDescription: 'SAWA يحتاج موقعك لإظهار الخدمات والوكلاء القريبين',
      NSLocationAlwaysAndWhenInUseUsageDescription: 'SAWA يحتاج موقعك لإظهار الخدمات القريبة',
      NSFaceIDUsageDescription: 'SAWA يستخدم Face ID لتأمين حسابك والمعاملات المالية',
      NSMicrophoneUsageDescription: 'SAWA يحتاج الميكروفون للرسائل الصوتية',
    },
    privacyManifests: {
      NSPrivacyAccessedAPITypes: [
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategoryUserDefaults',
          NSPrivacyAccessedAPITypeReasons: ['CA92.1'],
        },
        {
          NSPrivacyAccessedAPIType: 'NSPrivacyAccessedAPICategoryFileTimestamp',
          NSPrivacyAccessedAPITypeReasons: ['C617.1'],
        },
      ],
    },
    entitlements: {
      'com.apple.developer.associated-domains': ['applinks:sawa.app'],
    },
  },
  android: {
    package: 'com.sawa.android',
    versionCode: 1,
    adaptiveIcon: {
      foregroundImage: './assets/adaptive-icon.png',
      backgroundColor: '#08080F',
    },
    permissions: [
      'android.permission.CAMERA',
      'android.permission.READ_EXTERNAL_STORAGE',
      'android.permission.WRITE_EXTERNAL_STORAGE',
      'android.permission.ACCESS_FINE_LOCATION',
      'android.permission.ACCESS_COARSE_LOCATION',
      'android.permission.VIBRATE',
      'android.permission.USE_BIOMETRIC',
      'android.permission.USE_FINGERPRINT',
      'android.permission.INTERNET',
      'android.permission.RECEIVE_BOOT_COMPLETED',
      'android.permission.RECORD_AUDIO',
    ],
    intentFilters: [
      {
        action: 'VIEW',
        autoVerify: true,
        data: [{ scheme: 'https', host: 'sawa.app' }, { scheme: 'sawa' }],
        category: ['BROWSABLE', 'DEFAULT'],
      },
    ],
    googleServicesFile: './google-services.json',
  },
  plugins: [
    'expo-router',
    'expo-secure-store',
    'expo-local-authentication',
    ['expo-camera', { cameraPermission: 'SAWA يحتاج الكاميرا' }],
    ['expo-location', { locationAlwaysAndWhenInUsePermission: 'SAWA يحتاج موقعك' }],
    ['expo-notifications', { icon: './assets/notification-icon.png', color: '#00C896' }],
    ['expo-screen-capture', {}],
    ['expo-build-properties', {
      ios: { deploymentTarget: '16.0', newArchEnabled: true },
      android: { compileSdkVersion: 34, targetSdkVersion: 34, newArchEnabled: true },
    }],
    ['@sentry/react-native/expo', { organization: 'zein-apps', project: 'sawa-mobile' }],
  ],
  extra: {
    apiUrl: process.env['API_URL'] ?? 'http://localhost:3000',
    eas: { projectId: process.env['EAS_PROJECT_ID'] ?? '' },
  },
  owner: 'zein-apps',
  runtimeVersion: { policy: 'appVersion' },
});
