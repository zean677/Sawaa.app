/**
 * SAWA Mobile — API Service
 * Axios with JWT auto-refresh + idempotency + error handling
 */

import axios, { AxiosInstance, AxiosRequestConfig, AxiosError } from 'axios';
import { randomUUID } from 'expo-crypto';
import { secureStorage, useAuthStore } from '../stores';
import { APP_CONSTANTS } from '../constants';

const BASE_URL = process.env['EXPO_PUBLIC_API_URL'] ?? 'http://localhost:3000/api/v1';

// ── Create axios instance ─────────────────────────────────────
const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'X-API-Version': '1',
  },
});

// ── Request interceptor: inject JWT + Request ID ──────────────
api.interceptors.request.use(async (config) => {
  const token = await secureStorage.getToken();
  if (token) {
    config.headers['Authorization'] = `Bearer ${token}`;
  }
  config.headers['X-Request-ID'] = randomUUID();
  return config;
});

// ── Response interceptor: handle 401 + token refresh ─────────
let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };

    if (error.response?.status === 401 && !originalRequest._retry) {
      if (isRefreshing) {
        return new Promise((resolve) => {
          refreshQueue.push((token) => {
            if (originalRequest.headers) {
              originalRequest.headers['Authorization'] = `Bearer ${token}`;
            }
            resolve(api(originalRequest));
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const refreshToken = await secureStorage.getRefreshToken();
        if (!refreshToken) throw new Error('No refresh token');

        const { data } = await axios.post(`${BASE_URL}/auth/refresh`, { refreshToken });
        const { accessToken, refreshToken: newRefreshToken } = data.data;

        await secureStorage.setToken(accessToken);
        await secureStorage.setRefreshToken(newRefreshToken);

        refreshQueue.forEach((cb) => cb(accessToken));
        refreshQueue = [];

        if (originalRequest.headers) {
          originalRequest.headers['Authorization'] = `Bearer ${accessToken}`;
        }
        return api(originalRequest);
      } catch {
        refreshQueue = [];
        await useAuthStore.getState().logout();
        return Promise.reject(error);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  },
);

// ── API Methods ───────────────────────────────────────────────

// Auth
export const authApi = {
  sendOtp: (identifier: string) => api.post('/auth/send-otp', { identifier }),
  verifyOtp: (data: { identifier: string; code: string; deviceFingerprint?: string; deviceName?: string; deviceOs?: string }) =>
    api.post('/auth/verify-otp', data),
  refresh: (refreshToken: string) => api.post('/auth/refresh', { refreshToken }),
  logout: () => api.delete('/auth/logout'),
  logoutAll: () => api.delete('/auth/logout-all'),
  checkUsername: (username: string) => api.get(`/auth/check-username?username=${username}`),
  googleCallback: (code: string) => api.get(`/auth/google/callback?code=${code}`),
};

// Wallet
export const walletApi = {
  get: () => api.get('/wallet'),
  transfer: (data: { receiverIdentifier: string; identifierType: string; amountSp: string; note?: string }, idempotencyKey: string) =>
    api.post('/wallet/transfer', data, { headers: { 'X-Idempotency-Key': idempotencyKey } }),
  cancelTransfer: (txId: string) => api.post(`/wallet/transfer/${txId}/cancel`),
  getTransactions: (cursor?: string, type?: string) =>
    api.get('/wallet/transactions', { params: { cursor, type } }),
  lookupReceiver: (identifier: string, type: string) =>
    api.get('/wallet/lookup', { params: { identifier, type } }),
  updateCurrency: (currency: string) => api.post('/wallet/currency', { currency }),
  getExchangeRates: () => api.get('/wallet/rates'),
};

// Deposits
export const depositApi = {
  getMethods: () => api.get('/deposits/methods'),
  createRequest: (data: FormData) =>
    api.post('/deposits/request', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  cancel: (id: string) => api.delete(`/deposits/${id}`),
  getMyRequests: () => api.get('/deposits/my'),
};

// Escrow
export const escrowApi = {
  list: (status?: string) => api.get('/escrow', { params: { status } }),
  get: (id: string) => api.get(`/escrow/${id}`),
  create: (data: { sellerId: string; amountSp: string; description: string; deadline?: string; milestones?: Array<{ title: string; amountSp: string; deadline?: string }> }, idempotencyKey: string) =>
    api.post('/escrow', data, { headers: { 'X-Idempotency-Key': idempotencyKey } }),
  confirmDelivery: (id: string) => api.post(`/escrow/${id}/deliver`),
  confirmReceipt: (id: string) => api.post(`/escrow/${id}/confirm`),
  confirmMilestone: (id: string, mid: string) => api.post(`/escrow/${id}/milestone/${mid}/confirm`),
  openDispute: (id: string) => api.post(`/escrow/${id}/dispute`),
  requestCancel: (id: string) => api.post(`/escrow/${id}/cancel`),
};

// Market
export const marketApi = {
  list: (params?: { cursor?: string; category?: string; city?: string; minPrice?: string; maxPrice?: string }) =>
    api.get('/posts', { params }),
  get: (id: string) => api.get(`/posts/${id}`),
  create: (data: FormData) =>
    api.post('/posts', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  update: (id: string, data: Record<string, unknown>) => api.patch(`/posts/${id}`, data),
  delete: (id: string) => api.delete(`/posts/${id}`),
  renew: (id: string) => api.post(`/posts/${id}/renew`),
  boost: (id: string, days: 3 | 7 | 14) => api.post(`/posts/${id}/boost`, { days }),
  search: (query: string, params?: Record<string, string>) =>
    api.get('/search', { params: { q: query, ...params } }),
  nearby: (lat: number, lng: number, radius?: number) =>
    api.get('/posts/nearby', { params: { lat, lng, radius } }),
  getSimilar: (id: string) => api.get(`/posts/${id}/similar`),
};

// Agents
export const agentApi = {
  getNearby: (lat: number, lng: number) => api.get('/agents/nearby', { params: { lat, lng } }),
  apply: (data: FormData) =>
    api.post('/agents/apply', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  getMyProfile: () => api.get('/agents/me'),
  toggleAvailability: (available: boolean) => api.patch('/agents/availability', { available }),
  requestWithdrawal: (data: { amountSp: string; agentId?: string }, idempotencyKey: string) =>
    api.post('/agents/withdraw/request', data, { headers: { 'X-Idempotency-Key': idempotencyKey } }),
  confirmWithOtp: (operationId: string, otp: string) =>
    api.post('/agents/withdraw/confirm', { operationId, otp }),
};

// Notifications
export const notifApi = {
  list: (cursor?: string) => api.get('/notifications', { params: { cursor } }),
  markAllRead: () => api.patch('/notifications/read-all'),
  delete: (id: string) => api.delete(`/notifications/${id}`),
  registerDevice: (data: { fcmToken: string; deviceType: string; deviceFingerprint?: string }) =>
    api.post('/notifications/device', data),
  updateSettings: (settings: Record<string, boolean>) =>
    api.patch('/notifications/settings', settings),
};

// Profile
export const profileApi = {
  get: (username: string) => api.get(`/users/${username}`),
  update: (data: FormData) =>
    api.patch('/users/me', data, { headers: { 'Content-Type': 'multipart/form-data' } }),
  rate: (data: { reviewedId: string; quality: number; speed: number; honesty: number; communication: number; comment?: string; escrowId?: string }) =>
    api.post('/ratings', data),
  block: (userId: string) => api.post('/blocks', { userId }),
  unblock: (userId: string) => api.delete(`/blocks/${userId}`),
  report: (data: { targetType: string; targetId: string; reason: string; description?: string }) =>
    api.post('/reports', data),
  favorite: (targetType: string, targetId: string) =>
    api.post('/favorites', { targetType, targetId }),
  unfavorite: (targetType: string, targetId: string) =>
    api.delete('/favorites', { data: { targetType, targetId } }),
};

// Chat
export const chatApi = {
  list: () => api.get('/chats'),
  getMessages: (roomId: string, cursor?: string) =>
    api.get(`/chats/${roomId}/messages`, { params: { cursor } }),
  deleteMessage: (roomId: string, messageId: string) =>
    api.delete(`/chats/${roomId}/messages/${messageId}`),
  muteRoom: (roomId: string, until?: string) =>
    api.post(`/chats/${roomId}/mute`, { until }),
};

// Premium
export const premiumApi = {
  getStatus: () => api.get('/premium/status'),
  subscribe: (idempotencyKey: string) =>
    api.post('/premium/subscribe', {}, { headers: { 'X-Idempotency-Key': idempotencyKey } }),
  cancel: () => api.delete('/premium/cancel'),
  gift: (userId: string, idempotencyKey: string) =>
    api.post('/premium/gift', { userId }, { headers: { 'X-Idempotency-Key': idempotencyKey } }),
};

// AI
export const aiApi = {
  chat: (message: string) => api.post('/ai/chat', { message }),
};

// Health
export const healthApi = {
  check: () => api.get('/health'),
};

export default api;
