-- Initialize SAWA database extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "postgis";
CREATE EXTENSION IF NOT EXISTS "postgis_topology";
CREATE EXTENSION IF NOT EXISTS "unaccent";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create a read-only user for analytics
CREATE USER sawa_readonly WITH PASSWORD 'sawa_readonly_2024';
GRANT CONNECT ON DATABASE sawa_dev TO sawa_readonly;
GRANT USAGE ON SCHEMA public TO sawa_readonly;

-- Function to prevent UPDATE/DELETE on immutable tables
CREATE OR REPLACE FUNCTION prevent_mutation()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Table % is immutable. INSERT only.', TG_TABLE_NAME;
END;
$$ LANGUAGE plpgsql;
